import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { AppOverlay } from "@/components/app/AppOverlay";

const Scene = lazy(() => import("@/components/viewer/Scene"));

export const Route = createFileRoute("/")({ component: Home });

function BootScreen() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-bg text-fg">
      <p className="font-display text-2xl font-semibold tracking-tight">PS5 Visualiseur 3D</p>
      <p className="text-sm text-muted">Préparation du modèle…</p>
    </div>
  );
}

function Home() {
  return (
    <main className="relative h-dvh overflow-hidden bg-bg text-fg">
      <ClientOnly fallback={<BootScreen />}>
        <Suspense fallback={<BootScreen />}>
          <Scene />
        </Suspense>
      </ClientOnly>
      <AppOverlay />
    </main>
  );
}
