import { Button } from "@/components/ui/button";
import { useVizStore } from "@/lib/store";

const STEPS = [
  {
    title: "Bienvenue",
    body: "Explorez l’extérieur et l’intérieur de toutes les éditions PS5 en 3D, de l’Original à la Pro.",
  },
  {
    title: "Choisir une édition",
    body: "Ouvrez le menu Éditions pour comparer Original Disc, Digital, Slim et Pro. Le menu se replie pour laisser la scène respirer.",
  },
  {
    title: "Couches",
    body: "Affichez ou masquez panneaux, coque, ventilateur, dissipateur, carte mère, alimentation et lecteur Blu-ray.",
  },
  {
    title: "Modes de vue",
    body: "Passez d’une vue extérieure à une vue intérieure, éclatée, X-Ray, focus dissipateur ou présentation automatique.",
  },
  {
    title: "Contrôles 3D",
    body: "Glissez pour tourner, pincez ou utilisez la molette pour zoomer, clic droit ou deux doigts pour déplacer. Réinitialiser et Capture sont en haut à droite.",
  },
  {
    title: "Caractéristiques & mentions",
    body: "Le panneau technique détaille chaque édition. Lisez les mentions légales : ce visualiseur n’est pas un guide de démontage.",
  },
];

export function Tutorial() {
  const open = useVizStore((s) => s.tutorialOpen);
  const step = useVizStore((s) => s.tutorialStep);
  const nextTutorial = useVizStore((s) => s.nextTutorial);
  const skipTutorial = useVizStore((s) => s.skipTutorial);

  if (!open) return null;
  const current = STEPS[step] ?? STEPS[0];
  const last = step >= STEPS.length - 1;

  return (
    <div className="pointer-events-auto fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="tutorial-title"
        className="w-full max-w-md rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]"
      >
        <p className="text-xs font-medium uppercase tracking-wider text-accent">
          {step + 1} / {STEPS.length}
        </p>
        <h2
          id="tutorial-title"
          className="mt-2 font-display text-xl font-semibold tracking-tight text-fg text-balance"
        >
          {current.title}
        </h2>
        <p className="mt-2 text-sm leading-normal text-muted text-pretty">{current.body}</p>
        <div className="mt-5 flex items-center justify-between gap-3">
          <Button variant="ghost" size="sm" onClick={skipTutorial}>
            Passer
          </Button>
          <Button variant="primary" size="md" onClick={nextTutorial}>
            {last ? "Commencer" : "Suivant"}
          </Button>
        </div>
      </div>
    </div>
  );
}
