import { EDITIONS } from "@/lib/editions";
import { useVizStore } from "@/lib/store";

export function SpecsPanel() {
  const editionId = useVizStore((s) => s.edition);
  const edition = EDITIONS[editionId];

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h2 className="font-display text-lg font-semibold tracking-tight text-fg text-balance">
          {edition.name}
        </h2>
        <p className="mt-1 text-sm text-muted text-pretty">{edition.tagline}</p>
      </div>
      {edition.specs.map((section) => (
        <section key={section.title}>
          <h3 className="mb-2 text-xs font-medium uppercase tracking-wider text-faint">
            {section.title}
          </h3>
          <dl className="divide-y divide-border rounded-md bg-surface-2">
            {section.rows.map((row) => (
              <div key={row.label} className="flex items-baseline justify-between gap-4 px-3 py-2.5">
                <dt className="text-sm text-muted">{row.label}</dt>
                <dd className="text-right text-sm text-fg tabular-nums">{row.value}</dd>
              </div>
            ))}
          </dl>
        </section>
      ))}
    </div>
  );
}
