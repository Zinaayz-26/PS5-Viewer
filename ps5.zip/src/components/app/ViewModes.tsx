import { cn } from "@/lib/utils";
import { useVizStore, VIEW_META } from "@/lib/store";

export function ViewModes() {
  const viewMode = useVizStore((s) => s.viewMode);
  const setViewMode = useVizStore((s) => s.setViewMode);

  return (
    <div className="grid grid-cols-2 gap-2">
      {VIEW_META.map((mode) => {
        const active = mode.id === viewMode;
        return (
          <button
            key={mode.id}
            type="button"
            onClick={() => setViewMode(mode.id)}
            className={cn(
              "rounded-md px-3 py-3 text-left transition-[background-color,box-shadow] duration-[var(--motion-quick)]",
              active
                ? "bg-accent text-accent-fg"
                : "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
            )}
          >
            <span className="block text-sm font-medium leading-snug">{mode.label}</span>
            <span className={cn("mt-0.5 block text-xs", active ? "text-accent-fg/75" : "text-muted")}>
              {mode.hint}
            </span>
          </button>
        );
      })}
    </div>
  );
}
