import { ChevronLeft, ChevronRight } from "lucide-react";
import { EDITION_LIST, EDITIONS } from "@/lib/editions";
import { cn } from "@/lib/utils";
import { useVizStore } from "@/lib/store";

export function EditionsMenu({ compact = false }: { compact?: boolean }) {
  const edition = useVizStore((s) => s.edition);
  const setEdition = useVizStore((s) => s.setEdition);
  const open = useVizStore((s) => s.editionsOpen);
  const setOpen = useVizStore((s) => s.setEditionsOpen);

  if (compact) {
    return (
      <div className="flex flex-col gap-2">
        {EDITION_LIST.map((id) => {
          const item = EDITIONS[id];
          const active = id === edition;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setEdition(id)}
              className={cn(
                "rounded-md px-3 py-3 text-left transition-[background-color,box-shadow] duration-[var(--motion-quick)]",
                active
                  ? "bg-accent text-accent-fg"
                  : "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
              )}
            >
              <span className="block text-sm font-medium">{item.shortName}</span>
              <span className={cn("block text-xs", active ? "text-accent-fg/80" : "text-muted")}>
                {item.model}
                {item.hasDisc ? " · Lecteur" : " · Digital"}
              </span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <aside
      className={cn(
        "pointer-events-auto hidden h-full flex-col overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-[width,opacity] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)] lg:flex",
        open ? "w-64" : "w-12",
      )}
    >
      <div className="flex items-center justify-between gap-2 px-2.5 py-3">
        {open ? (
          <p className="pl-1.5 text-xs font-medium uppercase tracking-wider text-muted">Éditions</p>
        ) : null}
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex size-9 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg"
          aria-expanded={open}
          aria-label={open ? "Réduire le menu des éditions" : "Ouvrir le menu des éditions"}
        >
          {open ? <ChevronLeft className="size-4" /> : <ChevronRight className="size-4" />}
        </button>
      </div>
      <div className="flex flex-1 flex-col gap-1.5 overflow-y-auto px-2 pb-3">
        {EDITION_LIST.map((id) => {
          const item = EDITIONS[id];
          const active = id === edition;
          if (!open) {
            return (
              <button
                key={id}
                type="button"
                title={item.shortName}
                onClick={() => setEdition(id)}
                className={cn(
                  "mx-auto flex size-8 items-center justify-center rounded-sm text-[10px] font-semibold",
                  active ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg",
                )}
              >
                {item.generation === "pro"
                  ? "PR"
                  : item.generation === "slim"
                    ? "SL"
                    : "OR"}
              </button>
            );
          }
          return (
            <button
              key={id}
              type="button"
              onClick={() => setEdition(id)}
              className={cn(
                "rounded-md px-3 py-2.5 text-left transition-colors duration-[var(--motion-quick)]",
                active ? "bg-accent text-accent-fg" : "text-fg hover:bg-surface-2",
              )}
            >
              <span className="block text-sm font-medium leading-snug">{item.shortName}</span>
              <span className={cn("mt-0.5 block text-xs", active ? "text-accent-fg/75" : "text-muted")}>
                {item.model}
              </span>
            </button>
          );
        })}
      </div>
    </aside>
  );
}
