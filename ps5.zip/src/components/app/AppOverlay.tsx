import { Cpu, Gamepad2, Layers, Scan, ShieldAlert, X } from "lucide-react";
import { useEffect } from "react";
import { EditionsMenu } from "./EditionsMenu";
import { LayersPanel } from "./LayersPanel";
import { LegalContent, LegalStrip } from "./Legal";
import { SpecsPanel } from "./SpecsPanel";
import { TopBar } from "./TopBar";
import { Tutorial } from "./Tutorial";
import { ViewModes } from "./ViewModes";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  initTutorialFromStorage,
  useVizStore,
  type MobileSheet,
} from "@/lib/store";

const NAV: { id: MobileSheet; label: string; icon: typeof Layers }[] = [
  { id: "editions", label: "Éditions", icon: Gamepad2 },
  { id: "layers", label: "Couches", icon: Layers },
  { id: "modes", label: "Modes", icon: Scan },
  { id: "specs", label: "Specs", icon: Cpu },
  { id: "legal", label: "Mentions", icon: ShieldAlert },
];

function Sheet({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="pointer-events-auto lg:hidden">
      <button
        type="button"
        className="fixed inset-0 z-30 bg-bg/55"
        aria-label="Fermer"
        onClick={onClose}
      />
      <div className="fixed inset-x-0 bottom-0 z-40 max-h-[78dvh] overflow-y-auto rounded-t-xl bg-surface p-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] shadow-[var(--shadow-border)]">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-base font-semibold tracking-tight text-fg">{title}</h2>
          <Button variant="ghost" size="icon" aria-label="Fermer" onClick={onClose}>
            <X className="size-4" />
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
}

function DesktopDock() {
  const specsOpen = useVizStore((s) => s.specsOpen);
  const setSpecsOpen = useVizStore((s) => s.setSpecsOpen);

  return (
    <>
      <aside className="pointer-events-auto hidden w-72 shrink-0 flex-col gap-4 overflow-y-auto rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] lg:flex">
        <div>
          <p className="mb-2 px-1 text-xs font-medium uppercase tracking-wider text-muted">
            Modes de vue
          </p>
          <ViewModes />
        </div>
        <div>
          <p className="mb-2 px-1 text-xs font-medium uppercase tracking-wider text-muted">
            Couches
          </p>
          <LayersPanel />
        </div>
        <div className="mt-auto flex flex-col gap-2">
          <Button variant="outline" onClick={() => setSpecsOpen(!specsOpen)}>
            {specsOpen ? "Fermer les specs" : "Caractéristiques"}
          </Button>
        </div>
      </aside>

      {specsOpen ? (
        <div className="pointer-events-auto absolute bottom-16 left-1/2 z-20 hidden w-full max-w-xl -translate-x-1/2 overflow-y-auto rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] lg:block max-h-96">
          <div className="mb-2 flex justify-end">
            <Button variant="ghost" size="icon" aria-label="Fermer" onClick={() => setSpecsOpen(false)}>
              <X className="size-4" />
            </Button>
          </div>
          <SpecsPanel />
        </div>
      ) : null}
    </>
  );
}

export function AppOverlay() {
  const mobileSheet = useVizStore((s) => s.mobileSheet);
  const setMobileSheet = useVizStore((s) => s.setMobileSheet);
  const hintVisible = useVizStore((s) => s.hintVisible);
  const flash = useVizStore((s) => s.flash);
  const legalOpen = useVizStore((s) => s.legalOpen);
  const setLegalOpen = useVizStore((s) => s.setLegalOpen);

  useEffect(() => {
    initTutorialFromStorage();
  }, []);

  useEffect(() => {
    if (!legalOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLegalOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [legalOpen, setLegalOpen]);

  const sheetTitle =
    mobileSheet === "editions"
      ? "Éditions"
      : mobileSheet === "layers"
        ? "Couches"
        : mobileSheet === "modes"
          ? "Modes de vue"
          : mobileSheet === "specs"
            ? "Caractéristiques techniques"
            : mobileSheet === "legal"
              ? "Mentions légales"
              : "";

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col">
      <TopBar />

      <div className="flex min-h-0 flex-1 gap-3 px-3 pb-3">
        <EditionsMenu />
        <div className="relative min-w-0 flex-1">
          {hintVisible ? (
            <p className="pointer-events-none absolute bottom-3 left-1/2 hidden -translate-x-1/2 rounded-full bg-surface/90 px-3 py-1.5 text-xs text-muted shadow-[var(--shadow-border)] lg:block">
              Glissez pour tourner · molette pour zoomer
            </p>
          ) : null}
        </div>
        <DesktopDock />
      </div>

      <div className="px-3 pb-[calc(4.75rem+env(safe-area-inset-bottom))] lg:pb-3">
        <LegalStrip />
      </div>

      <nav className="pointer-events-auto fixed inset-x-0 bottom-0 z-20 flex items-stretch justify-around border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = mobileSheet === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setMobileSheet(active ? null : item.id)}
              className={cn(
                "flex h-14 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs",
                active ? "text-accent" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </button>
          );
        })}
      </nav>

      {mobileSheet ? (
        <Sheet title={sheetTitle} onClose={() => setMobileSheet(null)}>
          {mobileSheet === "editions" ? <EditionsMenu compact /> : null}
          {mobileSheet === "layers" ? <LayersPanel /> : null}
          {mobileSheet === "modes" ? <ViewModes /> : null}
          {mobileSheet === "specs" ? <SpecsPanel /> : null}
          {mobileSheet === "legal" ? <LegalContent /> : null}
        </Sheet>
      ) : null}

      <Tutorial />

      {legalOpen ? (
        <div className="pointer-events-auto fixed inset-0 z-40 flex items-center justify-center bg-bg/70 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="legal-title"
            className="relative w-full max-w-lg rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]"
          >
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-3 top-3"
              aria-label="Fermer"
              onClick={() => setLegalOpen(false)}
            >
              <X className="size-4" />
            </Button>
            <LegalContent />
          </div>
        </div>
      ) : null}

      {flash ? <div className="pointer-events-none fixed inset-0 z-40 bg-fg/20" /> : null}
    </div>
  );
}
