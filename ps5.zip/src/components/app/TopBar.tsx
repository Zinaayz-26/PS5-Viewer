import { Camera, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EDITIONS } from "@/lib/editions";
import { useVizStore } from "@/lib/store";

export function TopBar() {
  const edition = useVizStore((s) => s.edition);
  const requestCapture = useVizStore((s) => s.requestCapture);
  const requestReset = useVizStore((s) => s.requestReset);
  const meta = EDITIONS[edition];

  return (
    <header className="pointer-events-auto flex items-center justify-between gap-3 px-3 py-3 sm:px-4">
      <div className="min-w-0">
        <p className="font-display text-lg font-semibold leading-tight tracking-tight text-fg text-balance">
          PS5 Visualiseur 3D
        </p>
        <p className="truncate text-xs text-muted">
          {meta.shortName}
          <span className="text-faint"> · {meta.model}</span>
        </p>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="secondary"
          size="icon"
          aria-label="Réinitialiser la vue"
          onClick={requestReset}
        >
          <RotateCcw className="size-4" />
        </Button>
        <Button
          variant="primary"
          size="icon"
          aria-label="Capturer la vue"
          onClick={requestCapture}
        >
          <Camera className="size-4" />
        </Button>
      </div>
    </header>
  );
}
