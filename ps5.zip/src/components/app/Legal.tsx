import { useVizStore } from "@/lib/store";

const POINTS = [
  "Ce site n’est pas affilié à Sony Interactive Entertainment.",
  "Il s’agit d’un projet communautaire indépendant, à vocation pédagogique et de visualisation.",
  "L’auteur n’est pas responsable des dommages matériels ou corporels en cas de démontage d’une console réelle.",
  "Il est recommandé de suivre un tutoriel professionnel (par exemple iFixit) plutôt que de se baser uniquement sur ce visualiseur.",
];

export function LegalContent() {
  return (
    <div className="flex flex-col gap-4">
      <h2 className="font-display text-lg font-semibold tracking-tight text-fg">
        Mentions légales
      </h2>
      <ul className="flex flex-col gap-3">
        {POINTS.map((p) => (
          <li
            key={p}
            className="rounded-md bg-surface-2 px-3 py-3 text-sm leading-normal text-fg text-pretty shadow-[var(--shadow-border)]"
          >
            {p}
          </li>
        ))}
      </ul>
      <p className="text-xs leading-normal text-muted text-pretty">
        PlayStation, PS5 et les logos associés sont des marques de Sony Interactive
        Entertainment. Ce visualiseur 3D n’est ni un guide de réparation officiel, ni une
        représentation certifiée des pièces internes.
      </p>
    </div>
  );
}

export function LegalStrip() {
  const setLegalOpen = useVizStore((s) => s.setLegalOpen);

  return (
    <div className="pointer-events-auto flex items-center justify-between gap-3 rounded-lg bg-surface/90 px-3 py-2 shadow-[var(--shadow-border)]">
      <p className="min-w-0 truncate text-xs leading-snug text-muted">
        Projet indépendant, non affilié à Sony. Ne pas démonter une console en se basant
        uniquement sur ce visualiseur.
      </p>
      <button
        type="button"
        onClick={() => setLegalOpen(true)}
        className="shrink-0 text-xs font-medium text-accent hover:text-fg"
      >
        Mentions
      </button>
    </div>
  );
}
