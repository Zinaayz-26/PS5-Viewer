import { EDITIONS } from "@/lib/editions";
import { cn } from "@/lib/utils";
import { LAYER_META, useVizStore } from "@/lib/store";

export function LayersPanel() {
  const layers = useVizStore((s) => s.layers);
  const toggleLayer = useVizStore((s) => s.toggleLayer);
  const edition = useVizStore((s) => s.edition);
  const hasDisc = EDITIONS[edition].hasDisc;

  return (
    <div className="flex flex-col gap-1">
      {LAYER_META.map((item) => {
        const disabled = Boolean(item.discOnly && !hasDisc);
        const on = layers[item.key];
        return (
          <button
            key={item.key}
            type="button"
            disabled={disabled}
            onClick={() => toggleLayer(item.key)}
            className={cn(
              "flex h-11 items-center justify-between gap-3 rounded-md px-3 text-left transition-colors duration-[var(--motion-quick)]",
              disabled ? "opacity-40" : "hover:bg-surface-2",
            )}
            aria-pressed={on}
          >
            <span className="text-sm text-fg">{item.label}</span>
            <span
              className={cn(
                "relative h-6 w-10 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)]",
                on ? "bg-accent" : "bg-surface-2 shadow-[var(--shadow-border)]",
              )}
              aria-hidden
            >
              <span
                className={cn(
                  "absolute top-0.5 size-5 rounded-full bg-fg transition-transform duration-[var(--motion-quick)] ease-[var(--ease-smooth-out)]",
                  on ? "translate-x-4" : "translate-x-0.5",
                )}
              />
            </span>
          </button>
        );
      })}
    </div>
  );
}
