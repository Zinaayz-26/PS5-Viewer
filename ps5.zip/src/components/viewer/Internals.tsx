import { useLayoutEffect, useMemo, useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Edition } from "@/lib/editions";
import { PALETTE } from "@/lib/palette";
import { createHoneyTexture } from "./geometry";
import { useLayerGroup } from "./useLayerGroup";

function xrayOp(xray: boolean, solid: number, ghost: number) {
  return xray ? ghost : solid;
}

function Fan({
  edition,
  show,
  explode,
  xray,
}: {
  edition: Edition;
  show: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const r = gen === "pro" ? 0.56 : gen === "slim" ? 0.46 : 0.52;
  const y = edition.height * 0.28;
  const ref = useLayerGroup([0, y, 0.02], [0, 1.45, 0.15], show, explode);
  const blades = useRef<THREE.Group>(null);
  const count = gen === "pro" ? 9 : 7;

  useFrame((_, raw) => {
    if (!blades.current || !show) return;
    blades.current.rotation.y += 7.5 * Math.min(raw, 0.1);
  });

  return (
    <group ref={ref}>
      <mesh rotation={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[r + 0.04, r + 0.04, 0.09, 32]} />
        <meshStandardMaterial
          color={PALETTE.core}
          roughness={0.5}
          metalness={0.25}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.35)}
          depthWrite={!xray}
        />
      </mesh>
      <mesh>
        <cylinderGeometry args={[r * 0.22, r * 0.22, 0.1, 20]} />
        <meshStandardMaterial color={PALETTE.fanHub} metalness={0.4} roughness={0.4} />
      </mesh>
      <group ref={blades}>
        {Array.from({ length: count }, (_, i) => {
          const a = (i / count) * Math.PI * 2;
          return (
            <mesh
              key={i}
              position={[Math.sin(a) * r * 0.42, 0, Math.cos(a) * r * 0.42]}
              rotation={[0.45, a, 0.15]}
              castShadow
            >
              <boxGeometry args={[0.14, 0.018, r * 0.72]} />
              <meshStandardMaterial
                color={PALETTE.fanBlade}
                roughness={0.35}
                metalness={0.15}
                side={THREE.DoubleSide}
              />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}

function Heatsink({
  edition,
  show,
  explode,
  xray,
}: {
  edition: Edition;
  show: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const count = gen === "pro" ? 40 : gen === "slim" ? 22 : 30;
  const finH = gen === "pro" ? 1.15 : gen === "slim" ? 0.82 : 0.98;
  const finW = gen === "pro" ? 1.05 : gen === "slim" ? 0.82 : 0.92;
  const span = gen === "pro" ? 1.05 : gen === "slim" ? 0.78 : 0.92;
  const finT = 0.014;
  const y = edition.height * 0.02;
  const ref = useLayerGroup([0, y, -0.08], [0.7, 0.15, -0.1], show, explode);
  const meshRef = useRef<THREE.InstancedMesh>(null);

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const t = i / (count - 1);
      dummy.position.set(0, 0, THREE.MathUtils.lerp(-span / 2, span / 2, t));
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [count, span]);

  const pipes = gen === "pro" ? 5 : 3;

  return (
    <group ref={ref}>
      <mesh position={[0, -finH / 2 - 0.04, 0]} castShadow>
        <boxGeometry args={[finW * 0.72, 0.045, span * 0.85]} />
        <meshStandardMaterial
          color={PALETTE.copper}
          metalness={0.92}
          roughness={0.22}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.55)}
          depthWrite={!xray}
        />
      </mesh>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]} castShadow>
        <boxGeometry args={[finW, finH, finT]} />
        <meshStandardMaterial
          color={PALETTE.aluminum}
          metalness={0.86}
          roughness={0.22}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.45)}
          depthWrite={!xray}
        />
      </instancedMesh>
      {Array.from({ length: pipes }, (_, i) => {
        const z = (i - (pipes - 1) / 2) * 0.12;
        return (
          <mesh key={i} position={[-finW * 0.28, -finH * 0.15, z]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.018, 0.018, finW * 0.7, 10]} />
            <meshStandardMaterial
              color={PALETTE.copperPipe}
              metalness={0.9}
              roughness={0.18}
            />
          </mesh>
        );
      })}
    </group>
  );
}

function Motherboard({
  edition,
  show,
  explode,
  xray,
}: {
  edition: Edition;
  show: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const w = gen === "slim" ? 1.15 : 1.35;
  const d = gen === "slim" ? 1.35 : 1.55;
  const y = -edition.height * 0.02;
  const ref = useLayerGroup([-0.02, y, 0.02], [-0.85, -0.05, 0.15], show, explode);

  const chips = useMemo(() => {
    const extras = gen === "pro" ? 2 : 0;
    const base: [number, number][] = [
      [-0.28, 0.22],
      [0.28, 0.22],
      [-0.28, -0.22],
      [0.28, -0.22],
      [-0.42, 0],
      [0.42, 0],
      [0, 0.38],
      [0, -0.38],
    ];
    if (extras) base.push([-0.42, 0.38], [0.42, -0.38]);
    return base;
  }, [gen]);

  return (
    <group ref={ref}>
      <mesh receiveShadow castShadow>
        <boxGeometry args={[w, 0.035, d]} />
        <meshStandardMaterial
          color={PALETTE.pcb}
          roughness={0.62}
          metalness={0.08}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.5)}
          depthWrite={!xray}
        />
      </mesh>
      {/* APU */}
      <mesh position={[0, 0.05, 0]} castShadow>
        <boxGeometry args={[0.34, 0.055, 0.34]} />
        <meshStandardMaterial color={PALETTE.ihs} metalness={0.75} roughness={0.28} />
      </mesh>
      <mesh position={[0, 0.085, 0]}>
        <boxGeometry args={[0.2, 0.012, 0.2]} />
        <meshStandardMaterial color={PALETTE.silicon} roughness={0.4} />
      </mesh>
      {chips.map(([x, z], i) => (
        <mesh key={i} position={[x, 0.04, z]}>
          <boxGeometry args={[0.12, 0.03, 0.14]} />
          <meshStandardMaterial color={PALETTE.gddr} metalness={0.35} roughness={0.4} />
        </mesh>
      ))}
      {/* SSD */}
      <mesh position={[0, 0.04, d * 0.38]}>
        <boxGeometry args={[w * 0.55, 0.028, 0.16]} />
        <meshStandardMaterial color={PALETTE.core} metalness={0.4} roughness={0.35} />
      </mesh>
      {/* Capacitors */}
      {[-0.48, -0.38, 0.38, 0.48].map((x, i) => (
        <mesh key={i} position={[x, 0.06, -d * 0.32]}>
          <cylinderGeometry args={[0.025, 0.025, 0.07, 10]} />
          <meshStandardMaterial color="#1c2430" roughness={0.45} metalness={0.2} />
        </mesh>
      ))}
      {/* EMI shield */}
      <mesh position={[0, 0.12, 0]}>
        <boxGeometry args={[w * 0.92, 0.012, d * 0.88]} />
        <meshStandardMaterial
          color={PALETTE.shield}
          metalness={0.82}
          roughness={0.28}
          transparent
          opacity={xray ? 0.22 : 0.55}
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}

function PowerSupply({
  edition,
  show,
  explode,
  xray,
}: {
  edition: Edition;
  show: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const w = gen === "slim" ? 0.72 : 0.82;
  const h = gen === "pro" ? 0.72 : 0.58;
  const d = edition.depth * 0.55;
  const y = -edition.height * 0.32;
  const ref = useLayerGroup([0, y, 0], [0, -1.35, 0.1], show, explode);
  const honey = useMemo(() => createHoneyTexture(), []);
  useEffect(() => () => honey.dispose(), [honey]);

  return (
    <group ref={ref}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[w, h, d]} />
        <meshStandardMaterial
          color={PALETTE.psu}
          metalness={0.45}
          roughness={0.4}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.4)}
          depthWrite={!xray}
        />
      </mesh>
      <mesh position={[0, 0, d / 2 + 0.002]}>
        <planeGeometry args={[w * 0.85, h * 0.7]} />
        <meshStandardMaterial
          map={honey}
          color={PALETTE.psuMetal}
          metalness={0.5}
          roughness={0.45}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.4)}
        />
      </mesh>
      <mesh position={[0, h / 2 + 0.02, 0]}>
        <boxGeometry args={[0.18, 0.03, 0.12]} />
        <meshStandardMaterial color={PALETTE.aluminumDark} metalness={0.6} roughness={0.3} />
      </mesh>
    </group>
  );
}

function DiscDrive({
  edition,
  show,
  explode,
  xray,
}: {
  edition: Edition;
  show: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const slim = gen !== "original";
  const rest: [number, number, number] = slim
    ? [edition.width * 0.42, 0.05, 0]
    : [0.12, 0.06, edition.depth * 0.22];
  const exploded: [number, number, number] = slim
    ? [1.25, 0.1, 0.2]
    : [0.15, 0.1, 1.05];
  const ref = useLayerGroup(rest, exploded, show && edition.hasDisc, explode);
  const w = slim ? 0.22 : 0.55;
  const h = slim ? 1.55 : 0.22;
  const d = slim ? 1.7 : 1.15;

  return (
    <group ref={ref}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[w, h, d]} />
        <meshStandardMaterial
          color={PALETTE.drive}
          roughness={0.48}
          metalness={0.2}
          transparent={xray}
          opacity={xrayOp(xray, 1, 0.4)}
          depthWrite={!xray}
        />
      </mesh>
      <mesh position={slim ? [w / 2 + 0.002, 0.15, d / 2 - 0.08] : [0, 0, d / 2 + 0.002]}>
        <boxGeometry args={slim ? [0.02, 0.06, 0.55] : [0.42, 0.05, 0.02]} />
        <meshStandardMaterial color="#050508" roughness={0.7} />
      </mesh>
      <mesh position={slim ? [0, -h * 0.28, 0] : [0, 0.08, -0.1]}>
        <boxGeometry args={slim ? [w * 0.6, 0.12, d * 0.4] : [0.28, 0.05, 0.35]} />
        <meshStandardMaterial color={PALETTE.driveFace} metalness={0.35} roughness={0.4} />
      </mesh>
    </group>
  );
}

export function Internals({
  edition,
  layers,
  explode,
  xray,
}: {
  edition: Edition;
  layers: {
    fan: boolean;
    heatsink: boolean;
    motherboard: boolean;
    psu: boolean;
    discDrive: boolean;
  };
  explode: boolean;
  xray: boolean;
}) {
  return (
    <group>
      <Fan edition={edition} show={layers.fan} explode={explode} xray={xray} />
      <Heatsink edition={edition} show={layers.heatsink} explode={explode} xray={xray} />
      <Motherboard edition={edition} show={layers.motherboard} explode={explode} xray={xray} />
      <PowerSupply edition={edition} show={layers.psu} explode={explode} xray={xray} />
      <DiscDrive edition={edition} show={layers.discDrive} explode={explode} xray={xray} />
    </group>
  );
}
