import { EDITIONS } from "@/lib/editions";
import { useVizStore } from "@/lib/store";
import { ConsoleBody } from "./ConsoleBody";
import { Internals } from "./Internals";

export function PS5Model() {
  const editionId = useVizStore((s) => s.edition);
  const layers = useVizStore((s) => s.layers);
  const viewMode = useVizStore((s) => s.viewMode);
  const edition = EDITIONS[editionId];
  const explode = viewMode === "exploded";
  const xray = viewMode === "xray";

  return (
    <group key={edition.id}>
      <ConsoleBody
        edition={edition}
        showPanels={layers.sidePanels}
        showShell={layers.shell}
        explode={explode}
        xray={xray}
      />
      <Internals
        edition={edition}
        layers={layers}
        explode={explode}
        xray={xray}
      />
    </group>
  );
}
