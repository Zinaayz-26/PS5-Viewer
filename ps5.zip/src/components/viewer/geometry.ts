import * as THREE from "three";

export type WingParams = {
  height: number;
  depth: number;
  inner: number;
  outer: number;
  bulge: number;
  roundPower: number;
  zFlare: number;
  side: 1 | -1;
};

function xAt(
  ny: number,
  edge: "outer" | "inner",
  inner: number,
  outer: number,
  bulge: number,
  roundPower: number,
) {
  const absn = Math.min(1, Math.abs(ny));
  const cap = Math.pow(1 - Math.pow(absn, roundPower), 1 / roundPower);
  const midOuter = outer + bulge;
  const poleX = (inner + midOuter) * 0.5;
  if (edge === "outer") return poleX + (midOuter - poleX) * cap;
  return poleX + (inner - poleX) * cap;
}

export function createWingGeometry(p: WingParams): THREE.ExtrudeGeometry {
  const H = p.height / 2;
  const n = 72;
  const pts: THREE.Vector2[] = [];

  for (let i = 0; i <= n; i++) {
    const ny = 1 - (i / n) * 2;
    pts.push(
      new THREE.Vector2(
        xAt(ny, "outer", p.inner, p.outer, p.bulge, p.roundPower) * p.side,
        ny * H,
      ),
    );
  }
  for (let i = 0; i <= n; i++) {
    const ny = -1 + (i / n) * 2;
    pts.push(
      new THREE.Vector2(
        xAt(ny, "inner", p.inner, p.outer, p.bulge, p.roundPower) * p.side,
        ny * H,
      ),
    );
  }

  if (p.side === -1) pts.reverse();

  const shape = new THREE.Shape();
  shape.setFromPoints(pts);

  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: p.depth,
    bevelEnabled: true,
    bevelThickness: 0.038,
    bevelSize: 0.032,
    bevelSegments: 2,
    curveSegments: 4,
    steps: 1,
  });
  geo.translate(0, 0, -p.depth / 2);

  if (p.zFlare > 0) {
    const pos = geo.attributes.position;
    const h2 = p.height / 2;
    const d2 = p.depth / 2;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = pos.getZ(i);
      const zn = d2 === 0 ? 0 : z / d2;
      const yn = h2 === 0 ? 0 : y / h2;
      const flare = 1 + p.zFlare * (1 - zn * zn) * (1 - yn * yn);
      pos.setX(i, x * flare);
    }
    pos.needsUpdate = true;
  }

  geo.computeVertexNormals();
  return geo;
}

export function createVentTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 512;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#14161c";
  ctx.fillRect(0, 0, 128, 512);
  ctx.fillStyle = "#05060a";
  for (let y = 6; y < 512; y += 9) {
    ctx.fillRect(10, y, 108, 4);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createHoneyTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#2a2e36";
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = "#0d0f14";
  ctx.lineWidth = 3;
  const r = 8;
  for (let row = 0; row < 20; row++) {
    for (let col = 0; col < 18; col++) {
      const x = 12 + col * 14 + (row % 2 === 0 ? 0 : 7);
      const y = 10 + row * 13;
      ctx.beginPath();
      for (let k = 0; k < 6; k++) {
        const a = (Math.PI / 3) * k;
        const px = x + r * Math.cos(a);
        const py = y + r * Math.sin(a);
        if (k === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.repeat.set(2, 2);
  tex.needsUpdate = true;
  return tex;
}
