import { RoundedBox } from "@react-three/drei";
import { useEffect, useMemo } from "react";
import * as THREE from "three";
import type { Edition } from "@/lib/editions";
import { PALETTE } from "@/lib/palette";
import { createVentTexture, createWingGeometry, type WingParams } from "./geometry";
import { useLayerGroup } from "./useLayerGroup";

function xrayOp(xray: boolean, solid: number, ghost: number) {
  return xray ? ghost : solid;
}

function SidePanel({
  params,
  color,
  xray,
}: {
  params: WingParams;
  color: string;
  xray: boolean;
}) {
  const geo = useMemo(
    () => createWingGeometry(params),
    [
      params.height,
      params.depth,
      params.inner,
      params.outer,
      params.bulge,
      params.roundPower,
      params.zFlare,
      params.side,
    ],
  );
  useEffect(() => () => geo.dispose(), [geo]);

  return (
    <mesh geometry={geo} castShadow receiveShadow>
      <meshPhysicalMaterial
        color={color}
        roughness={0.3}
        metalness={0.04}
        clearcoat={0.42}
        clearcoatRoughness={0.26}
        transparent={xray}
        opacity={xrayOp(xray, 1, 0.2)}
        depthWrite={!xray}
        envMapIntensity={0.85}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function Ports({
  coreW,
  coreH,
  coreD,
  hasDisc,
  slimLike,
}: {
  coreW: number;
  coreH: number;
  coreD: number;
  hasDisc: boolean;
  slimLike: boolean;
}) {
  const zFront = coreD / 2 + 0.012;
  const zBack = -coreD / 2 - 0.012;
  return (
    <group>
      {/* Front USB / LED */}
      <mesh position={[slimLike ? 0 : -0.12, -coreH * 0.38, zFront]}>
        <boxGeometry args={[0.09, 0.045, 0.02]} />
        <meshStandardMaterial color={PALETTE.portSilver} metalness={0.7} roughness={0.35} />
      </mesh>
      {!slimLike ? (
        <mesh position={[0.12, -coreH * 0.38, zFront]}>
          <boxGeometry args={[0.07, 0.03, 0.018]} />
          <meshStandardMaterial color={PALETTE.core} roughness={0.5} />
        </mesh>
      ) : null}
      <mesh position={[0, -coreH * 0.28, zFront]}>
        <boxGeometry args={[0.035, 0.012, 0.01]} />
        <meshStandardMaterial
          color={PALETTE.led}
          emissive={PALETTE.led}
          emissiveIntensity={2.4}
        />
      </mesh>
      {hasDisc && !slimLike ? (
        <mesh position={[0, coreH * 0.08, zFront]}>
          <boxGeometry args={[coreW * 0.72, 0.055, 0.016]} />
          <meshStandardMaterial color="#050508" roughness={0.7} />
        </mesh>
      ) : null}

      {/* Rear I/O */}
      <mesh position={[0.12, -coreH * 0.12, zBack]}>
        <boxGeometry args={[0.16, 0.07, 0.03]} />
        <meshStandardMaterial color={PALETTE.portSilver} metalness={0.65} roughness={0.32} />
      </mesh>
      <mesh position={[-0.14, -coreH * 0.12, zBack]}>
        <boxGeometry args={[0.1, 0.08, 0.03]} />
        <meshStandardMaterial color={PALETTE.core} roughness={0.45} />
      </mesh>
      <mesh position={[0, -coreH * 0.32, zBack]}>
        <cylinderGeometry args={[0.045, 0.045, 0.03, 16]} />
        <meshStandardMaterial color={PALETTE.aluminumDark} metalness={0.6} roughness={0.3} />
      </mesh>
      <mesh position={[0.16, coreH * 0.18, zBack]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.025, 12]} />
        <meshStandardMaterial color={PALETTE.portSilver} metalness={0.7} roughness={0.28} />
      </mesh>
    </group>
  );
}

export function ConsoleBody({
  edition,
  showPanels,
  showShell,
  explode,
  xray,
}: {
  edition: Edition;
  showPanels: boolean;
  showShell: boolean;
  explode: boolean;
  xray: boolean;
}) {
  const gen = edition.generation;
  const panelColor =
    gen === "pro" ? PALETTE.panelPro : gen === "slim" ? PALETTE.panelSlim : PALETTE.panel;
  const coreColor = gen === "pro" ? PALETTE.corePro : PALETTE.core;
  const panelH = edition.height * 0.955;
  const panelD = edition.depth * 0.97;
  const coreW = edition.wing.inner * 2 - 0.04;
  const coreH = edition.height * 0.9;
  const coreD = edition.depth * 0.78;
  const standH = gen === "original" ? 0.11 : 0.08;
  const standY = -edition.height / 2 - standH * 0.35;

  const leftParams: WingParams = { ...edition.wing, height: panelH, depth: panelD, side: -1 };
  const rightParams: WingParams = { ...edition.wing, height: panelH, depth: panelD, side: 1 };

  const leftRef = useLayerGroup(
    [0, 0, 0],
    [-1.15, 0.05, 0],
    showPanels,
    explode,
  );
  const rightRef = useLayerGroup(
    [0, 0, 0],
    [1.15, 0.05, 0],
    showPanels,
    explode,
  );
  const shellRef = useLayerGroup([0, 0, 0], [0, 0.15, -0.35], showShell, explode);

  const ventTex = useMemo(() => createVentTexture(), []);
  useEffect(() => () => ventTex.dispose(), [ventTex]);

  const slimLike = gen !== "original";

  return (
    <group>
      <group ref={leftRef}>
        <SidePanel params={leftParams} color={panelColor} xray={xray} />
      </group>
      <group ref={rightRef}>
        <SidePanel params={rightParams} color={panelColor} xray={xray} />
      </group>

      <group ref={shellRef}>
        <RoundedBox args={[coreW, coreH, coreD]} radius={0.07} smoothness={4} castShadow receiveShadow>
          <meshPhysicalMaterial
            color={coreColor}
            roughness={0.48}
            metalness={0.18}
            transparent={xray}
            opacity={xrayOp(xray, 1, 0.18)}
            depthWrite={!xray}
          />
        </RoundedBox>

        <mesh position={[-coreW / 2 - 0.002, 0.05, 0]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[coreD * 0.72, coreH * 0.78]} />
          <meshStandardMaterial
            map={ventTex}
            color={PALETTE.vent}
            roughness={0.7}
            transparent={xray}
            opacity={xrayOp(xray, 1, 0.25)}
            depthWrite={!xray}
            side={THREE.DoubleSide}
          />
        </mesh>
        <mesh position={[coreW / 2 + 0.002, 0.05, 0]} rotation={[0, -Math.PI / 2, 0]}>
          <planeGeometry args={[coreD * 0.72, coreH * 0.78]} />
          <meshStandardMaterial
            map={ventTex}
            color={PALETTE.vent}
            roughness={0.7}
            transparent={xray}
            opacity={xrayOp(xray, 1, 0.25)}
            depthWrite={!xray}
            side={THREE.DoubleSide}
          />
        </mesh>

        <Ports
          coreW={coreW}
          coreH={coreH}
          coreD={coreD}
          hasDisc={edition.hasDisc && gen === "original"}
          slimLike={slimLike}
        />

        {gen === "pro" ? (
          <group position={[0, coreH * 0.36, coreD / 2 + 0.014]}>
            <mesh>
              <boxGeometry args={[0.22, 0.045, 0.01]} />
              <meshStandardMaterial
                color={PALETTE.badge}
                emissive={PALETTE.badge}
                emissiveIntensity={0.7}
                metalness={0.4}
                roughness={0.3}
              />
            </mesh>
          </group>
        ) : null}
      </group>

      <group position={[0, standY, 0]}>
        <mesh receiveShadow castShadow>
          <cylinderGeometry
            args={[
              gen === "original" ? 0.62 : 0.48,
              gen === "original" ? 0.7 : 0.54,
              standH,
              32,
            ]}
          />
          <meshPhysicalMaterial
            color={PALETTE.stand}
            roughness={0.55}
            metalness={0.2}
            transparent={xray}
            opacity={xrayOp(xray, 1, 0.35)}
            depthWrite={!xray}
          />
        </mesh>
        <mesh position={[0, standH * 0.55, 0]}>
          <cylinderGeometry args={[0.16, 0.16, 0.04, 20]} />
          <meshStandardMaterial color={PALETTE.rubber} roughness={0.85} />
        </mesh>
      </group>
    </group>
  );
}
