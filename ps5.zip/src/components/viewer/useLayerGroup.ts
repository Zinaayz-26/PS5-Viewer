import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useRef } from "react";
import * as THREE from "three";

const tmp = new THREE.Vector3();

export function useLayerGroup(
  rest: [number, number, number],
  exploded: [number, number, number],
  show: boolean,
  explode: boolean,
) {
  const ref = useRef<THREE.Group>(null);
  const booted = useRef(false);

  useLayoutEffect(() => {
    const g = ref.current;
    if (!g || booted.current) return;
    booted.current = true;
    const start = explode ? exploded : rest;
    g.position.set(start[0], start[1], start[2]);
    g.scale.setScalar(show ? 1 : 0.0001);
    g.visible = show;
  }, [explode, exploded, rest, show]);

  useFrame((_, raw) => {
    const g = ref.current;
    if (!g) return;
    const dt = Math.min(raw, 0.1);
    const k = 1 - Math.exp(-6 * dt);
    const target = explode ? exploded : rest;
    g.position.lerp(tmp.set(target[0], target[1], target[2]), k);
    const sTarget = show ? 1 : 0.0001;
    const s = THREE.MathUtils.lerp(g.scale.x, sTarget, k);
    g.scale.setScalar(s);
    g.visible = s > 0.02;
  });

  return ref;
}
