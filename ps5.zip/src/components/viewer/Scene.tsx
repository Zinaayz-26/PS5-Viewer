import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import { useEffect, useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { EDITIONS } from "@/lib/editions";
import { PALETTE } from "@/lib/palette";
import { useVizStore, type ViewMode } from "@/lib/store";
import { PS5Model } from "./PS5Model";

const CAM: Record<ViewMode, THREE.Vector3> = {
  exterior: new THREE.Vector3(4.15, 1.35, 5.7),
  interior: new THREE.Vector3(3.35, 0.9, 3.55),
  heatsink: new THREE.Vector3(2.15, 0.45, 2.25),
  exploded: new THREE.Vector3(5.4, 2.05, 6.2),
  presentation: new THREE.Vector3(4.4, 1.5, 5.9),
  xray: new THREE.Vector3(3.9, 1.55, 5.15),
};

const LOOK: Record<ViewMode, THREE.Vector3> = {
  exterior: new THREE.Vector3(0, 0.05, 0),
  interior: new THREE.Vector3(0, 0.05, 0),
  heatsink: new THREE.Vector3(0, 0.05, -0.05),
  exploded: new THREE.Vector3(0, 0.1, 0),
  presentation: new THREE.Vector3(0, 0.08, 0),
  xray: new THREE.Vector3(0, 0.05, 0),
};

function CameraRig({
  controlsRef,
}: {
  controlsRef: RefObject<OrbitControlsImpl | null>;
}) {
  const { camera } = useThree();
  const viewMode = useVizStore((s) => s.viewMode);
  const resetNonce = useVizStore((s) => s.resetNonce);
  const edition = useVizStore((s) => s.edition);
  const active = useRef(false);

  useEffect(() => {
    active.current = true;
    if (resetNonce > 0) {
      controlsRef.current?.reset();
    }
  }, [viewMode, resetNonce, edition, controlsRef]);

  useFrame((_, raw) => {
    const dt = Math.min(raw, 0.1);
    const controls = controlsRef.current;
    if (!controls || !active.current) return;
    const k = 1 - Math.exp(-3.2 * dt);
    camera.position.lerp(CAM[viewMode], k);
    controls.target.lerp(LOOK[viewMode], k);
    if (camera.position.distanceTo(CAM[viewMode]) < 0.03) {
      active.current = false;
    }
  }, 1);

  return null;
}

function CaptureAndHint() {
  const { gl } = useThree();
  const captureNonce = useVizStore((s) => s.captureNonce);
  const setFlash = useVizStore((s) => s.setFlash);
  const dismissHint = useVizStore((s) => s.dismissHint);
  const prev = useRef(0);

  useEffect(() => {
    const onPointer = () => dismissHint();
    gl.domElement.addEventListener("pointerdown", onPointer);
    return () => gl.domElement.removeEventListener("pointerdown", onPointer);
  }, [gl, dismissHint]);

  useEffect(() => {
    if (captureNonce === 0 || captureNonce === prev.current) return;
    prev.current = captureNonce;
    const edition = useVizStore.getState().edition;
    const url = gl.domElement.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `ps5-visualiseur-${edition}-${Date.now()}.png`;
    a.click();
    setFlash(true);
    const t = window.setTimeout(() => setFlash(false), 180);
    return () => window.clearTimeout(t);
  }, [captureNonce, gl, setFlash]);

  return null;
}

function Stage() {
  const editionId = useVizStore((s) => s.edition);
  const edition = EDITIONS[editionId];
  const standH = edition.generation === "original" ? 0.11 : 0.08;
  const y = -edition.height / 2 - standH * 0.85;

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]} receiveShadow>
        <circleGeometry args={[6.5, 64]} />
        <meshStandardMaterial color={PALETTE.bg} roughness={0.92} metalness={0.08} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y + 0.004, 0]}>
        <ringGeometry args={[1.55, 1.64, 64]} />
        <meshBasicMaterial color={PALETTE.stage} transparent opacity={0.28} />
      </mesh>
      <ContactShadows
        position={[0, y + 0.01, 0]}
        opacity={0.5}
        scale={9}
        blur={2.4}
        far={4}
        color="#000000"
      />
    </group>
  );
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.22} />
      <hemisphereLight args={[PALETTE.hemiSky, PALETTE.hemiGround, 0.55]} />
      <spotLight
        position={[5.2, 8.2, 6.2]}
        angle={0.36}
        penumbra={0.72}
        intensity={110}
        distance={32}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-bias={-0.0002}
      />
      <spotLight
        position={[-6.2, 3.4, -4.2]}
        angle={0.5}
        penumbra={0.9}
        intensity={38}
        color={PALETTE.led}
        distance={24}
      />
      <directionalLight position={[-2.8, 5.4, 4.2]} intensity={0.55} />
      <pointLight position={[0, -0.4, 2.4]} intensity={7} color={PALETTE.led} distance={7} />
    </>
  );
}

export default function Scene() {
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const viewMode = useVizStore((s) => s.viewMode);
  const autoRotate = viewMode === "presentation";
  const glConfig = useMemo(
    () => ({
      antialias: true,
      preserveDrawingBuffer: true,
      toneMapping: THREE.ACESFilmicToneMapping,
      toneMappingExposure: 1.08,
      powerPreference: "high-performance" as const,
    }),
    [],
  );

  return (
    <Canvas
      className="touch-none"
      shadows
      dpr={[1, 1.75]}
      gl={glConfig}
      camera={{ position: [4.15, 1.35, 5.7], fov: 34, near: 0.1, far: 60 }}
      style={{ position: "absolute", inset: 0, touchAction: "none" }}
      onCreated={({ scene, gl }) => {
        scene.background = new THREE.Color(PALETTE.bg);
        gl.setClearColor(PALETTE.bg, 1);
        gl.shadowMap.type = THREE.PCFSoftShadowMap;
      }}
    >
      <fog attach="fog" args={[PALETTE.bg, 11, 26]} />
      <Lights />
      <PS5Model />
      <Stage />
      <OrbitControls
        ref={controlsRef}
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={1.8}
        maxDistance={14}
        minPolarAngle={0.18}
        maxPolarAngle={Math.PI / 2 - 0.08}
        autoRotate={autoRotate}
        autoRotateSpeed={0.9}
        target={[0, 0.05, 0]}
      />
      <CameraRig controlsRef={controlsRef} />
      <CaptureAndHint />
    </Canvas>
  );
}
