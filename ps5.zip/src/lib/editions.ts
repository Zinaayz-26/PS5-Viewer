export type EditionId =
  | "original-disc"
  | "original-digital"
  | "slim-disc"
  | "slim-digital"
  | "pro";

export type Generation = "original" | "slim" | "pro";

export type SpecSection = {
  title: string;
  rows: { label: string; value: string }[];
};

export type Edition = {
  id: EditionId;
  generation: Generation;
  name: string;
  shortName: string;
  model: string;
  tagline: string;
  hasDisc: boolean;
  /** Display units: 1 unit = 10 cm. */
  height: number;
  width: number;
  depth: number;
  /** Wing profile. */
  wing: {
    inner: number;
    outer: number;
    bulge: number;
    roundPower: number;
    zFlare: number;
  };
  specs: SpecSection[];
};

export const EDITIONS: Record<EditionId, Edition> = {
  "original-disc": {
    id: "original-disc",
    generation: "original",
    name: "PS5 Original Disc",
    shortName: "Original Disc",
    model: "CFI-1000A",
    tagline: "L’édition disque fondatrice, ailes courbes et lecteur Ultra HD.",
    hasDisc: true,
    height: 3.9,
    width: 1.04,
    depth: 2.6,
    wing: { inner: 0.3, outer: 0.5, bulge: 0.1, roundPower: 6, zFlare: 0.05 },
    specs: [
      {
        title: "Identité",
        rows: [
          { label: "Modèle", value: "CFI-1000A / CFI-1016A" },
          { label: "Édition", value: "Disc Edition" },
          { label: "Génération", value: "Launch (2020)" },
        ],
      },
      {
        title: "Dimensions & poids",
        rows: [
          { label: "Dimensions", value: "390 × 104 × 260 mm" },
          { label: "Poids", value: "4,5 kg" },
          { label: "Orientation", value: "Verticale ou horizontale" },
        ],
      },
      {
        title: "Processeur",
        rows: [
          { label: "CPU", value: "AMD Zen 2, 8 cœurs / 16 threads" },
          { label: "Fréquence", value: "Jusqu’à 3,5 GHz (variable)" },
        ],
      },
      {
        title: "Graphismes",
        rows: [
          { label: "GPU", value: "AMD RDNA 2, 36 CU" },
          { label: "Fréquence", value: "Jusqu’à 2,23 GHz" },
          { label: "Puissance", value: "10,28 TFLOPS" },
          { label: "Sortie", value: "4K 120 Hz, 8K, VRR, HDMI 2.1" },
        ],
      },
      {
        title: "Mémoire & stockage",
        rows: [
          { label: "RAM", value: "16 Go GDDR6, 448 Go/s" },
          { label: "Stockage", value: "SSD custom 825 Go" },
          { label: "Débit SSD", value: "5,5 Go/s (brut)" },
          { label: "Extension", value: "SSD NVMe interne + USB" },
        ],
      },
      {
        title: "Alimentation & optique",
        rows: [
          { label: "PSU", value: "350 W" },
          { label: "Lecteur", value: "Ultra HD Blu-ray 4K" },
        ],
      },
      {
        title: "Connectique",
        rows: [
          { label: "Avant", value: "USB-A 2.0, USB-C 3.1" },
          { label: "Arrière", value: "HDMI 2.1, 2× USB-A 3.1, Ethernet, DC" },
          { label: "Sans fil", value: "Wi-Fi 6, Bluetooth 5.1" },
        ],
      },
    ],
  },
  "original-digital": {
    id: "original-digital",
    generation: "original",
    name: "PS5 Original Digital",
    shortName: "Original Digital",
    model: "CFI-1000B",
    tagline: "Même silhouette iconique, plus fine, sans lecteur disque.",
    hasDisc: false,
    height: 3.9,
    width: 0.92,
    depth: 2.6,
    wing: { inner: 0.26, outer: 0.45, bulge: 0.1, roundPower: 6, zFlare: 0.05 },
    specs: [
      {
        title: "Identité",
        rows: [
          { label: "Modèle", value: "CFI-1000B / CFI-1016B" },
          { label: "Édition", value: "Digital Edition" },
          { label: "Génération", value: "Launch (2020)" },
        ],
      },
      {
        title: "Dimensions & poids",
        rows: [
          { label: "Dimensions", value: "390 × 92 × 260 mm" },
          { label: "Poids", value: "3,9 kg" },
          { label: "Orientation", value: "Verticale ou horizontale" },
        ],
      },
      {
        title: "Processeur",
        rows: [
          { label: "CPU", value: "AMD Zen 2, 8 cœurs / 16 threads" },
          { label: "Fréquence", value: "Jusqu’à 3,5 GHz (variable)" },
        ],
      },
      {
        title: "Graphismes",
        rows: [
          { label: "GPU", value: "AMD RDNA 2, 36 CU" },
          { label: "Fréquence", value: "Jusqu’à 2,23 GHz" },
          { label: "Puissance", value: "10,28 TFLOPS" },
          { label: "Sortie", value: "4K 120 Hz, 8K, VRR, HDMI 2.1" },
        ],
      },
      {
        title: "Mémoire & stockage",
        rows: [
          { label: "RAM", value: "16 Go GDDR6, 448 Go/s" },
          { label: "Stockage", value: "SSD custom 825 Go" },
          { label: "Débit SSD", value: "5,5 Go/s (brut)" },
          { label: "Extension", value: "SSD NVMe interne + USB" },
        ],
      },
      {
        title: "Alimentation & optique",
        rows: [
          { label: "PSU", value: "350 W" },
          { label: "Lecteur", value: "Aucun — dématérialisé" },
        ],
      },
      {
        title: "Connectique",
        rows: [
          { label: "Avant", value: "USB-A 2.0, USB-C 3.1" },
          { label: "Arrière", value: "HDMI 2.1, 2× USB-A 3.1, Ethernet, DC" },
          { label: "Sans fil", value: "Wi-Fi 6, Bluetooth 5.1" },
        ],
      },
    ],
  },
  "slim-disc": {
    id: "slim-disc",
    generation: "slim",
    name: "PS5 Slim Disc",
    shortName: "Slim Disc",
    model: "CFI-2000",
    tagline: "Volume réduit, lecteur amovible, SSD 1 To.",
    hasDisc: true,
    height: 3.58,
    width: 0.96,
    depth: 2.16,
    wing: { inner: 0.28, outer: 0.42, bulge: 0.022, roundPower: 10, zFlare: 0.012 },
    specs: [
      {
        title: "Identité",
        rows: [
          { label: "Modèle", value: "CFI-2000 (chassis + lecteur)" },
          { label: "Édition", value: "Slim Disc Edition" },
          { label: "Génération", value: "Slim (2023)" },
        ],
      },
      {
        title: "Dimensions & poids",
        rows: [
          { label: "Dimensions", value: "358 × 96 × 216 mm" },
          { label: "Poids", value: "3,2 kg" },
          { label: "Lecteur", value: "Module amovible latéral" },
        ],
      },
      {
        title: "Processeur",
        rows: [
          { label: "CPU", value: "AMD Zen 2, 8 cœurs / 16 threads" },
          { label: "Fréquence", value: "Jusqu’à 3,5 GHz (variable)" },
        ],
      },
      {
        title: "Graphismes",
        rows: [
          { label: "GPU", value: "AMD RDNA 2, 36 CU" },
          { label: "Fréquence", value: "Jusqu’à 2,23 GHz" },
          { label: "Puissance", value: "10,28 TFLOPS" },
          { label: "Sortie", value: "4K 120 Hz, 8K, VRR, HDMI 2.1" },
        ],
      },
      {
        title: "Mémoire & stockage",
        rows: [
          { label: "RAM", value: "16 Go GDDR6, 448 Go/s" },
          { label: "Stockage", value: "SSD custom 1 To" },
          { label: "Débit SSD", value: "5,5 Go/s (brut)" },
          { label: "Extension", value: "SSD NVMe interne + USB" },
        ],
      },
      {
        title: "Alimentation & optique",
        rows: [
          { label: "PSU", value: "240 W (plus compact)" },
          { label: "Lecteur", value: "Ultra HD Blu-ray, amovible" },
        ],
      },
      {
        title: "Connectique",
        rows: [
          { label: "Avant", value: "USB-C" },
          { label: "Arrière", value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC" },
          { label: "Sans fil", value: "Wi-Fi 6E, Bluetooth 5.1" },
        ],
      },
    ],
  },
  "slim-digital": {
    id: "slim-digital",
    generation: "slim",
    name: "PS5 Slim Digital",
    shortName: "Slim Digital",
    model: "CFI-2000",
    tagline: "La plus compacte : 1 To, sans lecteur, panneaux plus plats.",
    hasDisc: false,
    height: 3.58,
    width: 0.8,
    depth: 2.16,
    wing: { inner: 0.24, outer: 0.38, bulge: 0.02, roundPower: 10, zFlare: 0.012 },
    specs: [
      {
        title: "Identité",
        rows: [
          { label: "Modèle", value: "CFI-2000 Digital" },
          { label: "Édition", value: "Slim Digital Edition" },
          { label: "Génération", value: "Slim (2023)" },
        ],
      },
      {
        title: "Dimensions & poids",
        rows: [
          { label: "Dimensions", value: "358 × 80 × 216 mm" },
          { label: "Poids", value: "2,6 kg" },
          { label: "Lecteur", value: "Compatible module optionnel" },
        ],
      },
      {
        title: "Processeur",
        rows: [
          { label: "CPU", value: "AMD Zen 2, 8 cœurs / 16 threads" },
          { label: "Fréquence", value: "Jusqu’à 3,5 GHz (variable)" },
        ],
      },
      {
        title: "Graphismes",
        rows: [
          { label: "GPU", value: "AMD RDNA 2, 36 CU" },
          { label: "Fréquence", value: "Jusqu’à 2,23 GHz" },
          { label: "Puissance", value: "10,28 TFLOPS" },
          { label: "Sortie", value: "4K 120 Hz, 8K, VRR, HDMI 2.1" },
        ],
      },
      {
        title: "Mémoire & stockage",
        rows: [
          { label: "RAM", value: "16 Go GDDR6, 448 Go/s" },
          { label: "Stockage", value: "SSD custom 1 To" },
          { label: "Débit SSD", value: "5,5 Go/s (brut)" },
          { label: "Extension", value: "SSD NVMe interne + USB" },
        ],
      },
      {
        title: "Alimentation & optique",
        rows: [
          { label: "PSU", value: "240 W (plus compact)" },
          { label: "Lecteur", value: "Aucun d’origine" },
        ],
      },
      {
        title: "Connectique",
        rows: [
          { label: "Avant", value: "USB-C" },
          { label: "Arrière", value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC" },
          { label: "Sans fil", value: "Wi-Fi 6E, Bluetooth 5.1" },
        ],
      },
    ],
  },
  pro: {
    id: "pro",
    generation: "pro",
    name: "PS5 Pro",
    shortName: "PS5 Pro",
    model: "CFI-7000",
    tagline: "GPU 60 CU, PSSR, SSD 2 To, refroidissement renforcé.",
    hasDisc: false,
    height: 3.88,
    width: 0.89,
    depth: 2.16,
    wing: { inner: 0.26, outer: 0.43, bulge: 0.036, roundPower: 8, zFlare: 0.02 },
    specs: [
      {
        title: "Identité",
        rows: [
          { label: "Modèle", value: "CFI-7000" },
          { label: "Édition", value: "PS5 Pro" },
          { label: "Génération", value: "Pro (2024)" },
        ],
      },
      {
        title: "Dimensions & poids",
        rows: [
          { label: "Dimensions", value: "388 × 89 × 216 mm" },
          { label: "Poids", value: "3,1 kg" },
          { label: "Lecteur", value: "Module Ultra HD optionnel" },
        ],
      },
      {
        title: "Processeur",
        rows: [
          { label: "CPU", value: "AMD Zen 2, 8 cœurs / 16 threads" },
          { label: "Fréquence", value: "Jusqu’à 3,85 GHz (mode haute freq.)" },
        ],
      },
      {
        title: "Graphismes",
        rows: [
          { label: "GPU", value: "RDNA 2/3, 60 CU" },
          { label: "Fréquence", value: "Jusqu’à 2,35 GHz" },
          { label: "Puissance", value: "16,7 TFLOPS + PSSR" },
          { label: "Sortie", value: "4K 120 Hz, 8K, VRR, HDMI 2.1" },
        ],
      },
      {
        title: "Mémoire & stockage",
        rows: [
          { label: "RAM", value: "16 Go GDDR6, 576 Go/s" },
          { label: "Système", value: "+ 2 Go DDR5 pour l’OS" },
          { label: "Stockage", value: "SSD custom 2 To" },
          { label: "Extension", value: "SSD NVMe interne + USB" },
        ],
      },
      {
        title: "Alimentation & optique",
        rows: [
          { label: "PSU", value: "390 W" },
          { label: "Lecteur", value: "Aucun d’origine (module optionnel)" },
        ],
      },
      {
        title: "Connectique",
        rows: [
          { label: "Avant", value: "USB-C" },
          { label: "Arrière", value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC" },
          { label: "Sans fil", value: "Wi-Fi 7, Bluetooth 5.1" },
        ],
      },
    ],
  },
};

export const EDITION_LIST: EditionId[] = [
  "original-disc",
  "original-digital",
  "slim-disc",
  "slim-digital",
  "pro",
];
