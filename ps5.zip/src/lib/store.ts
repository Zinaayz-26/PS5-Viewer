import { create } from "zustand";
import type { EditionId } from "@/lib/editions";

export type ViewMode =
  | "exterior"
  | "interior"
  | "heatsink"
  | "exploded"
  | "presentation"
  | "xray";

export type LayerKey =
  | "sidePanels"
  | "shell"
  | "fan"
  | "heatsink"
  | "motherboard"
  | "psu"
  | "discDrive";

export type Layers = Record<LayerKey, boolean>;

export type MobileSheet = "editions" | "layers" | "modes" | "specs" | "legal" | null;

const ALL_ON: Layers = {
  sidePanels: true,
  shell: true,
  fan: true,
  heatsink: true,
  motherboard: true,
  psu: true,
  discDrive: true,
};

const VIEW_PRESETS: Record<ViewMode, Layers> = {
  exterior: { ...ALL_ON },
  interior: {
    sidePanels: false,
    shell: false,
    fan: true,
    heatsink: true,
    motherboard: true,
    psu: true,
    discDrive: true,
  },
  heatsink: {
    sidePanels: false,
    shell: false,
    fan: false,
    heatsink: true,
    motherboard: true,
    psu: false,
    discDrive: false,
  },
  exploded: { ...ALL_ON },
  presentation: { ...ALL_ON },
  xray: { ...ALL_ON },
};

const TUTORIAL_KEY = "ps5-viz-tutorial-done";

type Store = {
  edition: EditionId;
  layers: Layers;
  viewMode: ViewMode;
  editionsOpen: boolean;
  specsOpen: boolean;
  legalOpen: boolean;
  tutorialOpen: boolean;
  tutorialStep: number;
  mobileSheet: MobileSheet;
  captureNonce: number;
  resetNonce: number;
  flash: boolean;
  hintVisible: boolean;
  setEdition: (id: EditionId) => void;
  toggleLayer: (key: LayerKey) => void;
  setViewMode: (mode: ViewMode) => void;
  setEditionsOpen: (open: boolean) => void;
  setSpecsOpen: (open: boolean) => void;
  setLegalOpen: (open: boolean) => void;
  setMobileSheet: (sheet: MobileSheet) => void;
  requestCapture: () => void;
  requestReset: () => void;
  setFlash: (v: boolean) => void;
  dismissHint: () => void;
  openTutorial: () => void;
  nextTutorial: () => void;
  skipTutorial: () => void;
};

function readTutorialDone() {
  if (typeof window === "undefined") return true;
  return window.localStorage.getItem(TUTORIAL_KEY) === "1";
}

function markTutorialDone() {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(TUTORIAL_KEY, "1");
}

export const useVizStore = create<Store>((set, get) => ({
  edition: "original-disc",
  layers: { ...ALL_ON },
  viewMode: "exterior",
  editionsOpen: true,
  specsOpen: false,
  legalOpen: false,
  tutorialOpen: false,
  tutorialStep: 0,
  mobileSheet: null,
  captureNonce: 0,
  resetNonce: 0,
  flash: false,
  hintVisible: true,
  setEdition: (id) => set({ edition: id }),
  toggleLayer: (key) =>
    set((s) => ({ layers: { ...s.layers, [key]: !s.layers[key] } })),
  setViewMode: (mode) => set({ viewMode: mode, layers: { ...VIEW_PRESETS[mode] } }),
  setEditionsOpen: (open) => set({ editionsOpen: open }),
  setSpecsOpen: (open) => set({ specsOpen: open }),
  setLegalOpen: (open) => set({ legalOpen: open }),
  setMobileSheet: (sheet) => set({ mobileSheet: sheet }),
  requestCapture: () => set((s) => ({ captureNonce: s.captureNonce + 1 })),
  requestReset: () =>
    set({
      viewMode: "exterior",
      layers: { ...ALL_ON },
      resetNonce: get().resetNonce + 1,
    }),
  setFlash: (v) => set({ flash: v }),
  dismissHint: () => set({ hintVisible: false }),
  openTutorial: () => set({ tutorialOpen: true, tutorialStep: 0 }),
  nextTutorial: () => {
    const step = get().tutorialStep;
    if (step >= 5) {
      markTutorialDone();
      set({ tutorialOpen: false, tutorialStep: 0 });
      return;
    }
    set({ tutorialStep: step + 1 });
  },
  skipTutorial: () => {
    markTutorialDone();
    set({ tutorialOpen: false, tutorialStep: 0 });
  },
}));

export function initTutorialFromStorage() {
  if (!readTutorialDone()) {
    useVizStore.getState().openTutorial();
  }
}

export const LAYER_META: {
  key: LayerKey;
  label: string;
  discOnly?: boolean;
}[] = [
  { key: "sidePanels", label: "Panneaux latéraux" },
  { key: "shell", label: "Coque extérieure" },
  { key: "fan", label: "Ventilateur" },
  { key: "heatsink", label: "Dissipateur thermique" },
  { key: "motherboard", label: "Carte mère + blindage" },
  { key: "psu", label: "Alimentation" },
  { key: "discDrive", label: "Lecteur Blu-ray", discOnly: true },
];

export const VIEW_META: { id: ViewMode; label: string; hint: string }[] = [
  { id: "exterior", label: "Extérieure", hint: "Console assemblée" },
  { id: "interior", label: "Intérieure", hint: "Coque retirée" },
  { id: "heatsink", label: "Focus dissipateur", hint: "Ailettes isolées" },
  { id: "exploded", label: "Vue éclatée", hint: "Pièces séparées" },
  { id: "presentation", label: "Présentation", hint: "Rotation auto" },
  { id: "xray", label: "X-Ray", hint: "Semi-transparent" },
];
