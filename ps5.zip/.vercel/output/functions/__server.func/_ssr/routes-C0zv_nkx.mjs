import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as RotateCcw, c as Cpu, d as Camera, i as Scan, l as ChevronRight, o as Layers, r as ShieldAlert, s as Gamepad2, t as X, u as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C0zv_nkx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var EDITIONS = {
	"original-disc": {
		id: "original-disc",
		generation: "original",
		name: "PS5 Original Disc",
		shortName: "Original Disc",
		model: "CFI-1000A",
		tagline: "L’édition disque fondatrice, ailes courbes et lecteur Ultra HD.",
		hasDisc: true,
		height: 3.9,
		width: 1.04,
		depth: 2.6,
		wing: {
			inner: .3,
			outer: .5,
			bulge: .1,
			roundPower: 6,
			zFlare: .05
		},
		specs: [
			{
				title: "Identité",
				rows: [
					{
						label: "Modèle",
						value: "CFI-1000A / CFI-1016A"
					},
					{
						label: "Édition",
						value: "Disc Edition"
					},
					{
						label: "Génération",
						value: "Launch (2020)"
					}
				]
			},
			{
				title: "Dimensions & poids",
				rows: [
					{
						label: "Dimensions",
						value: "390 × 104 × 260 mm"
					},
					{
						label: "Poids",
						value: "4,5 kg"
					},
					{
						label: "Orientation",
						value: "Verticale ou horizontale"
					}
				]
			},
			{
				title: "Processeur",
				rows: [{
					label: "CPU",
					value: "AMD Zen 2, 8 cœurs / 16 threads"
				}, {
					label: "Fréquence",
					value: "Jusqu’à 3,5 GHz (variable)"
				}]
			},
			{
				title: "Graphismes",
				rows: [
					{
						label: "GPU",
						value: "AMD RDNA 2, 36 CU"
					},
					{
						label: "Fréquence",
						value: "Jusqu’à 2,23 GHz"
					},
					{
						label: "Puissance",
						value: "10,28 TFLOPS"
					},
					{
						label: "Sortie",
						value: "4K 120 Hz, 8K, VRR, HDMI 2.1"
					}
				]
			},
			{
				title: "Mémoire & stockage",
				rows: [
					{
						label: "RAM",
						value: "16 Go GDDR6, 448 Go/s"
					},
					{
						label: "Stockage",
						value: "SSD custom 825 Go"
					},
					{
						label: "Débit SSD",
						value: "5,5 Go/s (brut)"
					},
					{
						label: "Extension",
						value: "SSD NVMe interne + USB"
					}
				]
			},
			{
				title: "Alimentation & optique",
				rows: [{
					label: "PSU",
					value: "350 W"
				}, {
					label: "Lecteur",
					value: "Ultra HD Blu-ray 4K"
				}]
			},
			{
				title: "Connectique",
				rows: [
					{
						label: "Avant",
						value: "USB-A 2.0, USB-C 3.1"
					},
					{
						label: "Arrière",
						value: "HDMI 2.1, 2× USB-A 3.1, Ethernet, DC"
					},
					{
						label: "Sans fil",
						value: "Wi-Fi 6, Bluetooth 5.1"
					}
				]
			}
		]
	},
	"original-digital": {
		id: "original-digital",
		generation: "original",
		name: "PS5 Original Digital",
		shortName: "Original Digital",
		model: "CFI-1000B",
		tagline: "Même silhouette iconique, plus fine, sans lecteur disque.",
		hasDisc: false,
		height: 3.9,
		width: .92,
		depth: 2.6,
		wing: {
			inner: .26,
			outer: .45,
			bulge: .1,
			roundPower: 6,
			zFlare: .05
		},
		specs: [
			{
				title: "Identité",
				rows: [
					{
						label: "Modèle",
						value: "CFI-1000B / CFI-1016B"
					},
					{
						label: "Édition",
						value: "Digital Edition"
					},
					{
						label: "Génération",
						value: "Launch (2020)"
					}
				]
			},
			{
				title: "Dimensions & poids",
				rows: [
					{
						label: "Dimensions",
						value: "390 × 92 × 260 mm"
					},
					{
						label: "Poids",
						value: "3,9 kg"
					},
					{
						label: "Orientation",
						value: "Verticale ou horizontale"
					}
				]
			},
			{
				title: "Processeur",
				rows: [{
					label: "CPU",
					value: "AMD Zen 2, 8 cœurs / 16 threads"
				}, {
					label: "Fréquence",
					value: "Jusqu’à 3,5 GHz (variable)"
				}]
			},
			{
				title: "Graphismes",
				rows: [
					{
						label: "GPU",
						value: "AMD RDNA 2, 36 CU"
					},
					{
						label: "Fréquence",
						value: "Jusqu’à 2,23 GHz"
					},
					{
						label: "Puissance",
						value: "10,28 TFLOPS"
					},
					{
						label: "Sortie",
						value: "4K 120 Hz, 8K, VRR, HDMI 2.1"
					}
				]
			},
			{
				title: "Mémoire & stockage",
				rows: [
					{
						label: "RAM",
						value: "16 Go GDDR6, 448 Go/s"
					},
					{
						label: "Stockage",
						value: "SSD custom 825 Go"
					},
					{
						label: "Débit SSD",
						value: "5,5 Go/s (brut)"
					},
					{
						label: "Extension",
						value: "SSD NVMe interne + USB"
					}
				]
			},
			{
				title: "Alimentation & optique",
				rows: [{
					label: "PSU",
					value: "350 W"
				}, {
					label: "Lecteur",
					value: "Aucun — dématérialisé"
				}]
			},
			{
				title: "Connectique",
				rows: [
					{
						label: "Avant",
						value: "USB-A 2.0, USB-C 3.1"
					},
					{
						label: "Arrière",
						value: "HDMI 2.1, 2× USB-A 3.1, Ethernet, DC"
					},
					{
						label: "Sans fil",
						value: "Wi-Fi 6, Bluetooth 5.1"
					}
				]
			}
		]
	},
	"slim-disc": {
		id: "slim-disc",
		generation: "slim",
		name: "PS5 Slim Disc",
		shortName: "Slim Disc",
		model: "CFI-2000",
		tagline: "Volume réduit, lecteur amovible, SSD 1 To.",
		hasDisc: true,
		height: 3.58,
		width: .96,
		depth: 2.16,
		wing: {
			inner: .28,
			outer: .42,
			bulge: .022,
			roundPower: 10,
			zFlare: .012
		},
		specs: [
			{
				title: "Identité",
				rows: [
					{
						label: "Modèle",
						value: "CFI-2000 (chassis + lecteur)"
					},
					{
						label: "Édition",
						value: "Slim Disc Edition"
					},
					{
						label: "Génération",
						value: "Slim (2023)"
					}
				]
			},
			{
				title: "Dimensions & poids",
				rows: [
					{
						label: "Dimensions",
						value: "358 × 96 × 216 mm"
					},
					{
						label: "Poids",
						value: "3,2 kg"
					},
					{
						label: "Lecteur",
						value: "Module amovible latéral"
					}
				]
			},
			{
				title: "Processeur",
				rows: [{
					label: "CPU",
					value: "AMD Zen 2, 8 cœurs / 16 threads"
				}, {
					label: "Fréquence",
					value: "Jusqu’à 3,5 GHz (variable)"
				}]
			},
			{
				title: "Graphismes",
				rows: [
					{
						label: "GPU",
						value: "AMD RDNA 2, 36 CU"
					},
					{
						label: "Fréquence",
						value: "Jusqu’à 2,23 GHz"
					},
					{
						label: "Puissance",
						value: "10,28 TFLOPS"
					},
					{
						label: "Sortie",
						value: "4K 120 Hz, 8K, VRR, HDMI 2.1"
					}
				]
			},
			{
				title: "Mémoire & stockage",
				rows: [
					{
						label: "RAM",
						value: "16 Go GDDR6, 448 Go/s"
					},
					{
						label: "Stockage",
						value: "SSD custom 1 To"
					},
					{
						label: "Débit SSD",
						value: "5,5 Go/s (brut)"
					},
					{
						label: "Extension",
						value: "SSD NVMe interne + USB"
					}
				]
			},
			{
				title: "Alimentation & optique",
				rows: [{
					label: "PSU",
					value: "240 W (plus compact)"
				}, {
					label: "Lecteur",
					value: "Ultra HD Blu-ray, amovible"
				}]
			},
			{
				title: "Connectique",
				rows: [
					{
						label: "Avant",
						value: "USB-C"
					},
					{
						label: "Arrière",
						value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC"
					},
					{
						label: "Sans fil",
						value: "Wi-Fi 6E, Bluetooth 5.1"
					}
				]
			}
		]
	},
	"slim-digital": {
		id: "slim-digital",
		generation: "slim",
		name: "PS5 Slim Digital",
		shortName: "Slim Digital",
		model: "CFI-2000",
		tagline: "La plus compacte : 1 To, sans lecteur, panneaux plus plats.",
		hasDisc: false,
		height: 3.58,
		width: .8,
		depth: 2.16,
		wing: {
			inner: .24,
			outer: .38,
			bulge: .02,
			roundPower: 10,
			zFlare: .012
		},
		specs: [
			{
				title: "Identité",
				rows: [
					{
						label: "Modèle",
						value: "CFI-2000 Digital"
					},
					{
						label: "Édition",
						value: "Slim Digital Edition"
					},
					{
						label: "Génération",
						value: "Slim (2023)"
					}
				]
			},
			{
				title: "Dimensions & poids",
				rows: [
					{
						label: "Dimensions",
						value: "358 × 80 × 216 mm"
					},
					{
						label: "Poids",
						value: "2,6 kg"
					},
					{
						label: "Lecteur",
						value: "Compatible module optionnel"
					}
				]
			},
			{
				title: "Processeur",
				rows: [{
					label: "CPU",
					value: "AMD Zen 2, 8 cœurs / 16 threads"
				}, {
					label: "Fréquence",
					value: "Jusqu’à 3,5 GHz (variable)"
				}]
			},
			{
				title: "Graphismes",
				rows: [
					{
						label: "GPU",
						value: "AMD RDNA 2, 36 CU"
					},
					{
						label: "Fréquence",
						value: "Jusqu’à 2,23 GHz"
					},
					{
						label: "Puissance",
						value: "10,28 TFLOPS"
					},
					{
						label: "Sortie",
						value: "4K 120 Hz, 8K, VRR, HDMI 2.1"
					}
				]
			},
			{
				title: "Mémoire & stockage",
				rows: [
					{
						label: "RAM",
						value: "16 Go GDDR6, 448 Go/s"
					},
					{
						label: "Stockage",
						value: "SSD custom 1 To"
					},
					{
						label: "Débit SSD",
						value: "5,5 Go/s (brut)"
					},
					{
						label: "Extension",
						value: "SSD NVMe interne + USB"
					}
				]
			},
			{
				title: "Alimentation & optique",
				rows: [{
					label: "PSU",
					value: "240 W (plus compact)"
				}, {
					label: "Lecteur",
					value: "Aucun d’origine"
				}]
			},
			{
				title: "Connectique",
				rows: [
					{
						label: "Avant",
						value: "USB-C"
					},
					{
						label: "Arrière",
						value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC"
					},
					{
						label: "Sans fil",
						value: "Wi-Fi 6E, Bluetooth 5.1"
					}
				]
			}
		]
	},
	pro: {
		id: "pro",
		generation: "pro",
		name: "PS5 Pro",
		shortName: "PS5 Pro",
		model: "CFI-7000",
		tagline: "GPU 60 CU, PSSR, SSD 2 To, refroidissement renforcé.",
		hasDisc: false,
		height: 3.88,
		width: .89,
		depth: 2.16,
		wing: {
			inner: .26,
			outer: .43,
			bulge: .036,
			roundPower: 8,
			zFlare: .02
		},
		specs: [
			{
				title: "Identité",
				rows: [
					{
						label: "Modèle",
						value: "CFI-7000"
					},
					{
						label: "Édition",
						value: "PS5 Pro"
					},
					{
						label: "Génération",
						value: "Pro (2024)"
					}
				]
			},
			{
				title: "Dimensions & poids",
				rows: [
					{
						label: "Dimensions",
						value: "388 × 89 × 216 mm"
					},
					{
						label: "Poids",
						value: "3,1 kg"
					},
					{
						label: "Lecteur",
						value: "Module Ultra HD optionnel"
					}
				]
			},
			{
				title: "Processeur",
				rows: [{
					label: "CPU",
					value: "AMD Zen 2, 8 cœurs / 16 threads"
				}, {
					label: "Fréquence",
					value: "Jusqu’à 3,85 GHz (mode haute freq.)"
				}]
			},
			{
				title: "Graphismes",
				rows: [
					{
						label: "GPU",
						value: "RDNA 2/3, 60 CU"
					},
					{
						label: "Fréquence",
						value: "Jusqu’à 2,35 GHz"
					},
					{
						label: "Puissance",
						value: "16,7 TFLOPS + PSSR"
					},
					{
						label: "Sortie",
						value: "4K 120 Hz, 8K, VRR, HDMI 2.1"
					}
				]
			},
			{
				title: "Mémoire & stockage",
				rows: [
					{
						label: "RAM",
						value: "16 Go GDDR6, 576 Go/s"
					},
					{
						label: "Système",
						value: "+ 2 Go DDR5 pour l’OS"
					},
					{
						label: "Stockage",
						value: "SSD custom 2 To"
					},
					{
						label: "Extension",
						value: "SSD NVMe interne + USB"
					}
				]
			},
			{
				title: "Alimentation & optique",
				rows: [{
					label: "PSU",
					value: "390 W"
				}, {
					label: "Lecteur",
					value: "Aucun d’origine (module optionnel)"
				}]
			},
			{
				title: "Connectique",
				rows: [
					{
						label: "Avant",
						value: "USB-C"
					},
					{
						label: "Arrière",
						value: "HDMI 2.1, 2× USB-A, USB-C, Ethernet, DC"
					},
					{
						label: "Sans fil",
						value: "Wi-Fi 7, Bluetooth 5.1"
					}
				]
			}
		]
	}
};
var EDITION_LIST = [
	"original-disc",
	"original-digital",
	"slim-disc",
	"slim-digital",
	"pro"
];
var ALL_ON = {
	sidePanels: true,
	shell: true,
	fan: true,
	heatsink: true,
	motherboard: true,
	psu: true,
	discDrive: true
};
var VIEW_PRESETS = {
	exterior: { ...ALL_ON },
	interior: {
		sidePanels: false,
		shell: false,
		fan: true,
		heatsink: true,
		motherboard: true,
		psu: true,
		discDrive: true
	},
	heatsink: {
		sidePanels: false,
		shell: false,
		fan: false,
		heatsink: true,
		motherboard: true,
		psu: false,
		discDrive: false
	},
	exploded: { ...ALL_ON },
	presentation: { ...ALL_ON },
	xray: { ...ALL_ON }
};
var TUTORIAL_KEY = "ps5-viz-tutorial-done";
function readTutorialDone() {
	if (typeof window === "undefined") return true;
	return window.localStorage.getItem(TUTORIAL_KEY) === "1";
}
function markTutorialDone() {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(TUTORIAL_KEY, "1");
}
var useVizStore = create((set, get) => ({
	edition: "original-disc",
	layers: { ...ALL_ON },
	viewMode: "exterior",
	editionsOpen: true,
	specsOpen: false,
	legalOpen: false,
	tutorialOpen: false,
	tutorialStep: 0,
	mobileSheet: null,
	captureNonce: 0,
	resetNonce: 0,
	flash: false,
	hintVisible: true,
	setEdition: (id) => set({ edition: id }),
	toggleLayer: (key) => set((s) => ({ layers: {
		...s.layers,
		[key]: !s.layers[key]
	} })),
	setViewMode: (mode) => set({
		viewMode: mode,
		layers: { ...VIEW_PRESETS[mode] }
	}),
	setEditionsOpen: (open) => set({ editionsOpen: open }),
	setSpecsOpen: (open) => set({ specsOpen: open }),
	setLegalOpen: (open) => set({ legalOpen: open }),
	setMobileSheet: (sheet) => set({ mobileSheet: sheet }),
	requestCapture: () => set((s) => ({ captureNonce: s.captureNonce + 1 })),
	requestReset: () => set({
		viewMode: "exterior",
		layers: { ...ALL_ON },
		resetNonce: get().resetNonce + 1
	}),
	setFlash: (v) => set({ flash: v }),
	dismissHint: () => set({ hintVisible: false }),
	openTutorial: () => set({
		tutorialOpen: true,
		tutorialStep: 0
	}),
	nextTutorial: () => {
		const step = get().tutorialStep;
		if (step >= 5) {
			markTutorialDone();
			set({
				tutorialOpen: false,
				tutorialStep: 0
			});
			return;
		}
		set({ tutorialStep: step + 1 });
	},
	skipTutorial: () => {
		markTutorialDone();
		set({
			tutorialOpen: false,
			tutorialStep: 0
		});
	}
}));
function initTutorialFromStorage() {
	if (!readTutorialDone()) useVizStore.getState().openTutorial();
}
var LAYER_META = [
	{
		key: "sidePanels",
		label: "Panneaux latéraux"
	},
	{
		key: "shell",
		label: "Coque extérieure"
	},
	{
		key: "fan",
		label: "Ventilateur"
	},
	{
		key: "heatsink",
		label: "Dissipateur thermique"
	},
	{
		key: "motherboard",
		label: "Carte mère + blindage"
	},
	{
		key: "psu",
		label: "Alimentation"
	},
	{
		key: "discDrive",
		label: "Lecteur Blu-ray",
		discOnly: true
	}
];
var VIEW_META = [
	{
		id: "exterior",
		label: "Extérieure",
		hint: "Console assemblée"
	},
	{
		id: "interior",
		label: "Intérieure",
		hint: "Coque retirée"
	},
	{
		id: "heatsink",
		label: "Focus dissipateur",
		hint: "Ailettes isolées"
	},
	{
		id: "exploded",
		label: "Vue éclatée",
		hint: "Pièces séparées"
	},
	{
		id: "presentation",
		label: "Présentation",
		hint: "Rotation auto"
	},
	{
		id: "xray",
		label: "X-Ray",
		hint: "Semi-transparent"
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function EditionsMenu({ compact = false }) {
	const edition = useVizStore((s) => s.edition);
	const setEdition = useVizStore((s) => s.setEdition);
	const open = useVizStore((s) => s.editionsOpen);
	const setOpen = useVizStore((s) => s.setEditionsOpen);
	if (compact) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-2",
		children: EDITION_LIST.map((id) => {
			const item = EDITIONS[id];
			const active = id === edition;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setEdition(id),
				className: cn("rounded-md px-3 py-3 text-left transition-[background-color,box-shadow] duration-[var(--motion-quick)]", active ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium",
					children: item.shortName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("block text-xs", active ? "text-accent-fg/80" : "text-muted"),
					children: [item.model, item.hasDisc ? " · Lecteur" : " · Digital"]
				})]
			}, id);
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("pointer-events-auto hidden h-full flex-col overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-[width,opacity] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)] lg:flex", open ? "w-64" : "w-12"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 px-2.5 py-3",
			children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pl-1.5 text-xs font-medium uppercase tracking-wider text-muted",
				children: "Éditions"
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen(!open),
				className: "flex size-9 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg",
				"aria-expanded": open,
				"aria-label": open ? "Réduire le menu des éditions" : "Ouvrir le menu des éditions",
				children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-1 flex-col gap-1.5 overflow-y-auto px-2 pb-3",
			children: EDITION_LIST.map((id) => {
				const item = EDITIONS[id];
				const active = id === edition;
				if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					title: item.shortName,
					onClick: () => setEdition(id),
					className: cn("mx-auto flex size-8 items-center justify-center rounded-sm text-[10px] font-semibold", active ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg"),
					children: item.generation === "pro" ? "PR" : item.generation === "slim" ? "SL" : "OR"
				}, id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setEdition(id),
					className: cn("rounded-md px-3 py-2.5 text-left transition-colors duration-[var(--motion-quick)]", active ? "bg-accent text-accent-fg" : "text-fg hover:bg-surface-2"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium leading-snug",
						children: item.shortName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 block text-xs", active ? "text-accent-fg/75" : "text-muted"),
						children: item.model
					})]
				}, id);
			})
		})]
	});
}
function LayersPanel() {
	const layers = useVizStore((s) => s.layers);
	const toggleLayer = useVizStore((s) => s.toggleLayer);
	const hasDisc = EDITIONS[useVizStore((s) => s.edition)].hasDisc;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-1",
		children: LAYER_META.map((item) => {
			const disabled = Boolean(item.discOnly && !hasDisc);
			const on = layers[item.key];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled,
				onClick: () => toggleLayer(item.key),
				className: cn("flex h-11 items-center justify-between gap-3 rounded-md px-3 text-left transition-colors duration-[var(--motion-quick)]", disabled ? "opacity-40" : "hover:bg-surface-2"),
				"aria-pressed": on,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-fg",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("relative h-6 w-10 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)]", on ? "bg-accent" : "bg-surface-2 shadow-[var(--shadow-border)]"),
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-5 rounded-full bg-fg transition-transform duration-[var(--motion-quick)] ease-[var(--ease-smooth-out)]", on ? "translate-x-4" : "translate-x-0.5") })
				})]
			}, item.key);
		})
	});
}
var POINTS = [
	"Ce site n’est pas affilié à Sony Interactive Entertainment.",
	"Il s’agit d’un projet communautaire indépendant, à vocation pédagogique et de visualisation.",
	"L’auteur n’est pas responsable des dommages matériels ou corporels en cas de démontage d’une console réelle.",
	"Il est recommandé de suivre un tutoriel professionnel (par exemple iFixit) plutôt que de se baser uniquement sur ce visualiseur."
];
function LegalContent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold tracking-tight text-fg",
				children: "Mentions légales"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: POINTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-md bg-surface-2 px-3 py-3 text-sm leading-normal text-fg text-pretty shadow-[var(--shadow-border)]",
					children: p
				}, p))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-normal text-muted text-pretty",
				children: "PlayStation, PS5 et les logos associés sont des marques de Sony Interactive Entertainment. Ce visualiseur 3D n’est ni un guide de réparation officiel, ni une représentation certifiée des pièces internes."
			})
		]
	});
}
function LegalStrip() {
	const setLegalOpen = useVizStore((s) => s.setLegalOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-auto flex items-center justify-between gap-3 rounded-lg bg-surface/90 px-3 py-2 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "min-w-0 truncate text-xs leading-snug text-muted",
			children: "Projet indépendant, non affilié à Sony. Ne pas démonter une console en se basant uniquement sur ce visualiseur."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setLegalOpen(true),
			className: "shrink-0 text-xs font-medium text-accent hover:text-fg",
			children: "Mentions"
		})]
	});
}
function SpecsPanel() {
	const edition = EDITIONS[useVizStore((s) => s.edition)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg font-semibold tracking-tight text-fg text-balance",
			children: edition.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted text-pretty",
			children: edition.tagline
		})] }), edition.specs.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-2 text-xs font-medium uppercase tracking-wider text-faint",
			children: section.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "divide-y divide-border rounded-md bg-surface-2",
			children: section.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-4 px-3 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm text-muted",
					children: row.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "text-right text-sm text-fg tabular-nums",
					children: row.value
				})]
			}, row.label))
		})] }, section.title))]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-smooth-out)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:text-fg hover:bg-surface-2",
			outline: "text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] bg-transparent"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-sm",
			md: "h-11 px-4 text-sm rounded-md",
			icon: "size-11 rounded-md",
			pill: "h-10 px-3.5 text-sm rounded-full"
		}
	},
	defaultVariants: {
		variant: "secondary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		type: asChild ? void 0 : type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function TopBar() {
	const edition = useVizStore((s) => s.edition);
	const requestCapture = useVizStore((s) => s.requestCapture);
	const requestReset = useVizStore((s) => s.requestReset);
	const meta = EDITIONS[edition];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-auto flex items-center justify-between gap-3 px-3 py-3 sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg font-semibold leading-tight tracking-tight text-fg text-balance",
				children: "PS5 Visualiseur 3D"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "truncate text-xs text-muted",
				children: [meta.shortName, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-faint",
					children: [" · ", meta.model]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				size: "icon",
				"aria-label": "Réinitialiser la vue",
				onClick: requestReset,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				size: "icon",
				"aria-label": "Capturer la vue",
				onClick: requestCapture,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
			})]
		})]
	});
}
var STEPS = [
	{
		title: "Bienvenue",
		body: "Explorez l’extérieur et l’intérieur de toutes les éditions PS5 en 3D, de l’Original à la Pro."
	},
	{
		title: "Choisir une édition",
		body: "Ouvrez le menu Éditions pour comparer Original Disc, Digital, Slim et Pro. Le menu se replie pour laisser la scène respirer."
	},
	{
		title: "Couches",
		body: "Affichez ou masquez panneaux, coque, ventilateur, dissipateur, carte mère, alimentation et lecteur Blu-ray."
	},
	{
		title: "Modes de vue",
		body: "Passez d’une vue extérieure à une vue intérieure, éclatée, X-Ray, focus dissipateur ou présentation automatique."
	},
	{
		title: "Contrôles 3D",
		body: "Glissez pour tourner, pincez ou utilisez la molette pour zoomer, clic droit ou deux doigts pour déplacer. Réinitialiser et Capture sont en haut à droite."
	},
	{
		title: "Caractéristiques & mentions",
		body: "Le panneau technique détaille chaque édition. Lisez les mentions légales : ce visualiseur n’est pas un guide de démontage."
	}
];
function Tutorial() {
	const open = useVizStore((s) => s.tutorialOpen);
	const step = useVizStore((s) => s.tutorialStep);
	const nextTutorial = useVizStore((s) => s.nextTutorial);
	const skipTutorial = useVizStore((s) => s.skipTutorial);
	if (!open) return null;
	const current = STEPS[step] ?? STEPS[0];
	const last = step >= STEPS.length - 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-auto fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "tutorial-title",
			className: "w-full max-w-md rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium uppercase tracking-wider text-accent",
					children: [
						step + 1,
						" / ",
						STEPS.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "tutorial-title",
					className: "mt-2 font-display text-xl font-semibold tracking-tight text-fg text-balance",
					children: current.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-normal text-muted text-pretty",
					children: current.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: skipTutorial,
						children: "Passer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						size: "md",
						onClick: nextTutorial,
						children: last ? "Commencer" : "Suivant"
					})]
				})
			]
		})
	});
}
function ViewModes() {
	const viewMode = useVizStore((s) => s.viewMode);
	const setViewMode = useVizStore((s) => s.setViewMode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2",
		children: VIEW_META.map((mode) => {
			const active = mode.id === viewMode;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setViewMode(mode.id),
				className: cn("rounded-md px-3 py-3 text-left transition-[background-color,box-shadow] duration-[var(--motion-quick)]", active ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium leading-snug",
					children: mode.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("mt-0.5 block text-xs", active ? "text-accent-fg/75" : "text-muted"),
					children: mode.hint
				})]
			}, mode.id);
		})
	});
}
var NAV = [
	{
		id: "editions",
		label: "Éditions",
		icon: Gamepad2
	},
	{
		id: "layers",
		label: "Couches",
		icon: Layers
	},
	{
		id: "modes",
		label: "Modes",
		icon: Scan
	},
	{
		id: "specs",
		label: "Specs",
		icon: Cpu
	},
	{
		id: "legal",
		label: "Mentions",
		icon: ShieldAlert
	}
];
function Sheet({ title, children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-auto lg:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "fixed inset-0 z-30 bg-bg/55",
			"aria-label": "Fermer",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-x-0 bottom-0 z-40 max-h-[78dvh] overflow-y-auto rounded-t-xl bg-surface p-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-base font-semibold tracking-tight text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Fermer",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})]
	});
}
function DesktopDock() {
	const specsOpen = useVizStore((s) => s.specsOpen);
	const setSpecsOpen = useVizStore((s) => s.setSpecsOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "pointer-events-auto hidden w-72 shrink-0 flex-col gap-4 overflow-y-auto rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] lg:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 px-1 text-xs font-medium uppercase tracking-wider text-muted",
				children: "Modes de vue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewModes, {})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 px-1 text-xs font-medium uppercase tracking-wider text-muted",
				children: "Couches"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersPanel, {})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto flex flex-col gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setSpecsOpen(!specsOpen),
					children: specsOpen ? "Fermer les specs" : "Caractéristiques"
				})
			})
		]
	}), specsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-auto absolute bottom-16 left-1/2 z-20 hidden w-full max-w-xl -translate-x-1/2 overflow-y-auto rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] lg:block max-h-96",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-2 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Fermer",
				onClick: () => setSpecsOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecsPanel, {})]
	}) : null] });
}
function AppOverlay() {
	const mobileSheet = useVizStore((s) => s.mobileSheet);
	const setMobileSheet = useVizStore((s) => s.setMobileSheet);
	const hintVisible = useVizStore((s) => s.hintVisible);
	const flash = useVizStore((s) => s.flash);
	const legalOpen = useVizStore((s) => s.legalOpen);
	const setLegalOpen = useVizStore((s) => s.setLegalOpen);
	(0, import_react.useEffect)(() => {
		initTutorialFromStorage();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!legalOpen) return;
		const onKey = (e) => {
			if (e.key === "Escape") setLegalOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [legalOpen, setLegalOpen]);
	const sheetTitle = mobileSheet === "editions" ? "Éditions" : mobileSheet === "layers" ? "Couches" : mobileSheet === "modes" ? "Modes de vue" : mobileSheet === "specs" ? "Caractéristiques techniques" : mobileSheet === "legal" ? "Mentions légales" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 gap-3 px-3 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditionsMenu, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative min-w-0 flex-1",
						children: hintVisible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pointer-events-none absolute bottom-3 left-1/2 hidden -translate-x-1/2 rounded-full bg-surface/90 px-3 py-1.5 text-xs text-muted shadow-[var(--shadow-border)] lg:block",
							children: "Glissez pour tourner · molette pour zoomer"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopDock, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-[calc(4.75rem+env(safe-area-inset-bottom))] lg:pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalStrip, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "pointer-events-auto fixed inset-x-0 bottom-0 z-20 flex items-stretch justify-around border-t border-border bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden",
				children: NAV.map((item) => {
					const Icon = item.icon;
					const active = mobileSheet === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMobileSheet(active ? null : item.id),
						className: cn("flex h-14 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-xs", active ? "text-accent" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
					}, item.id);
				})
			}),
			mobileSheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: sheetTitle,
				onClose: () => setMobileSheet(null),
				children: [
					mobileSheet === "editions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditionsMenu, { compact: true }) : null,
					mobileSheet === "layers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersPanel, {}) : null,
					mobileSheet === "modes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewModes, {}) : null,
					mobileSheet === "specs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecsPanel, {}) : null,
					mobileSheet === "legal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalContent, {}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tutorial, {}),
			legalOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto fixed inset-0 z-40 flex items-center justify-center bg-bg/70 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "legal-title",
					className: "relative w-full max-w-lg rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "absolute right-3 top-3",
						"aria-label": "Fermer",
						onClick: () => setLegalOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalContent, {})]
				})
			}) : null,
			flash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed inset-0 z-40 bg-fg/20" }) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
var Scene = (0, import_react.lazy)(() => import("./Scene-BxeAhL2K.mjs"));
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 flex flex-col items-center justify-center gap-3 bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl font-semibold tracking-tight",
			children: "PS5 Visualiseur 3D"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Préparation du modèle…"
		})]
	});
}
function Home() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh overflow-hidden bg-bg text-fg",
		children: [mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
			fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppOverlay, {})]
	});
}
//#endregion
export { useVizStore as n, EDITIONS as r, routes_exports as t };
