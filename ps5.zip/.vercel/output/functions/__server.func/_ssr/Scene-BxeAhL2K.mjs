import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Vector3, a as useFrame, c as CanvasTexture, d as MathUtils, f as Object3D, g as Vector2, h as Shape, i as Canvas, l as Color, m as SRGBColorSpace, n as RoundedBox, o as useThree, p as RepeatWrapping, r as OrbitControls, t as ContactShadows, u as ExtrudeGeometry, y as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as useVizStore, r as EDITIONS } from "./routes-C0zv_nkx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Scene-BxeAhL2K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** 3D material colors — kept here so the canvas does not scatter literals. */
var PALETTE = {
	bg: "#07080c",
	panel: "#e7e9ef",
	panelSlim: "#eceef3",
	panelPro: "#dedfe6",
	core: "#12141a",
	corePro: "#0e1016",
	stand: "#0b0d12",
	vent: "#0a0a0d",
	aluminum: "#c5ccd6",
	aluminumDark: "#8b93a0",
	copper: "#b87333",
	copperPipe: "#c9894a",
	pcb: "#143d2e",
	pcbTrace: "#1f5a44",
	silicon: "#1c1c22",
	ihs: "#d7dbe3",
	gddr: "#1a1b21",
	chipGold: "#9a7b3c",
	psu: "#2a2e36",
	psuMetal: "#6d7480",
	drive: "#1a1c22",
	driveFace: "#2c3038",
	fanHub: "#2b2e36",
	fanBlade: "#3a3f4a",
	led: "#3d7fff",
	portSilver: "#b8bec8",
	rubber: "#1a1a1e",
	shield: "#9aa3b0",
	badge: "#3d7fff",
	stage: "#3d7fff",
	hemiSky: "#9eb3d1",
	hemiGround: "#0c0e14"
};
function xAt(ny, edge, inner, outer, bulge, roundPower) {
	const cap = Math.pow(1 - Math.pow(Math.min(1, Math.abs(ny)), roundPower), 1 / roundPower);
	const midOuter = outer + bulge;
	const poleX = (inner + midOuter) * .5;
	if (edge === "outer") return poleX + (midOuter - poleX) * cap;
	return poleX + (inner - poleX) * cap;
}
function createWingGeometry(p) {
	const H = p.height / 2;
	const n = 72;
	const pts = [];
	for (let i = 0; i <= n; i++) {
		const ny = 1 - i / n * 2;
		pts.push(new Vector2(xAt(ny, "outer", p.inner, p.outer, p.bulge, p.roundPower) * p.side, ny * H));
	}
	for (let i = 0; i <= n; i++) {
		const ny = -1 + i / n * 2;
		pts.push(new Vector2(xAt(ny, "inner", p.inner, p.outer, p.bulge, p.roundPower) * p.side, ny * H));
	}
	if (p.side === -1) pts.reverse();
	const shape = new Shape();
	shape.setFromPoints(pts);
	const geo = new ExtrudeGeometry(shape, {
		depth: p.depth,
		bevelEnabled: true,
		bevelThickness: .038,
		bevelSize: .032,
		bevelSegments: 2,
		curveSegments: 4,
		steps: 1
	});
	geo.translate(0, 0, -p.depth / 2);
	if (p.zFlare > 0) {
		const pos = geo.attributes.position;
		const h2 = p.height / 2;
		const d2 = p.depth / 2;
		for (let i = 0; i < pos.count; i++) {
			const x = pos.getX(i);
			const y = pos.getY(i);
			const z = pos.getZ(i);
			const zn = d2 === 0 ? 0 : z / d2;
			const yn = h2 === 0 ? 0 : y / h2;
			const flare = 1 + p.zFlare * (1 - zn * zn) * (1 - yn * yn);
			pos.setX(i, x * flare);
		}
		pos.needsUpdate = true;
	}
	geo.computeVertexNormals();
	return geo;
}
function createVentTexture() {
	const c = document.createElement("canvas");
	c.width = 128;
	c.height = 512;
	const ctx = c.getContext("2d");
	ctx.fillStyle = "#14161c";
	ctx.fillRect(0, 0, 128, 512);
	ctx.fillStyle = "#05060a";
	for (let y = 6; y < 512; y += 9) ctx.fillRect(10, y, 108, 4);
	const tex = new CanvasTexture(c);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.anisotropy = 8;
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
function createHoneyTexture() {
	const c = document.createElement("canvas");
	c.width = 256;
	c.height = 256;
	const ctx = c.getContext("2d");
	ctx.fillStyle = "#2a2e36";
	ctx.fillRect(0, 0, 256, 256);
	ctx.strokeStyle = "#0d0f14";
	ctx.lineWidth = 3;
	const r = 8;
	for (let row = 0; row < 20; row++) for (let col = 0; col < 18; col++) {
		const x = 12 + col * 14 + (row % 2 === 0 ? 0 : 7);
		const y = 10 + row * 13;
		ctx.beginPath();
		for (let k = 0; k < 6; k++) {
			const a = Math.PI / 3 * k;
			const px = x + r * Math.cos(a);
			const py = y + r * Math.sin(a);
			if (k === 0) ctx.moveTo(px, py);
			else ctx.lineTo(px, py);
		}
		ctx.closePath();
		ctx.stroke();
	}
	const tex = new CanvasTexture(c);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.colorSpace = SRGBColorSpace;
	tex.repeat.set(2, 2);
	tex.needsUpdate = true;
	return tex;
}
var tmp = new Vector3();
function useLayerGroup(rest, exploded, show, explode) {
	const ref = (0, import_react.useRef)(null);
	const booted = (0, import_react.useRef)(false);
	(0, import_react.useLayoutEffect)(() => {
		const g = ref.current;
		if (!g || booted.current) return;
		booted.current = true;
		const start = explode ? exploded : rest;
		g.position.set(start[0], start[1], start[2]);
		g.scale.setScalar(show ? 1 : 1e-4);
		g.visible = show;
	}, [
		explode,
		exploded,
		rest,
		show
	]);
	useFrame((_, raw) => {
		const g = ref.current;
		if (!g) return;
		const k = 1 - Math.exp(-6 * Math.min(raw, .1));
		const target = explode ? exploded : rest;
		g.position.lerp(tmp.set(target[0], target[1], target[2]), k);
		const sTarget = show ? 1 : 1e-4;
		const s = MathUtils.lerp(g.scale.x, sTarget, k);
		g.scale.setScalar(s);
		g.visible = s > .02;
	});
	return ref;
}
function xrayOp$1(xray, solid, ghost) {
	return xray ? ghost : solid;
}
function SidePanel({ params, color, xray }) {
	const geo = (0, import_react.useMemo)(() => createWingGeometry(params), [
		params.height,
		params.depth,
		params.inner,
		params.outer,
		params.bulge,
		params.roundPower,
		params.zFlare,
		params.side
	]);
	(0, import_react.useEffect)(() => () => geo.dispose(), [geo]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		geometry: geo,
		castShadow: true,
		receiveShadow: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
			color,
			roughness: .3,
			metalness: .04,
			clearcoat: .42,
			clearcoatRoughness: .26,
			transparent: xray,
			opacity: xrayOp$1(xray, 1, .2),
			depthWrite: !xray,
			envMapIntensity: .85,
			side: 2
		})
	});
}
function Ports({ coreW, coreH, coreD, hasDisc, slimLike }) {
	const zFront = coreD / 2 + .012;
	const zBack = -coreD / 2 - .012;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				slimLike ? 0 : -.12,
				-coreH * .38,
				zFront
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.09,
				.045,
				.02
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.portSilver,
				metalness: .7,
				roughness: .35
			})]
		}),
		!slimLike ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.12,
				-coreH * .38,
				zFront
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.07,
				.03,
				.018
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.core,
				roughness: .5
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				-coreH * .28,
				zFront
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.035,
				.012,
				.01
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.led,
				emissive: PALETTE.led,
				emissiveIntensity: 2.4
			})]
		}),
		hasDisc && !slimLike ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				coreH * .08,
				zFront
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				coreW * .72,
				.055,
				.016
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#050508",
				roughness: .7
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.12,
				-coreH * .12,
				zBack
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.16,
				.07,
				.03
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.portSilver,
				metalness: .65,
				roughness: .32
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-.14,
				-coreH * .12,
				zBack
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.1,
				.08,
				.03
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.core,
				roughness: .45
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				-coreH * .32,
				zBack
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.045,
				.045,
				.03,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.aluminumDark,
				metalness: .6,
				roughness: .3
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.16,
				coreH * .18,
				zBack
			],
			rotation: [
				Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.03,
				.03,
				.025,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.portSilver,
				metalness: .7,
				roughness: .28
			})]
		})
	] });
}
function ConsoleBody({ edition, showPanels, showShell, explode, xray }) {
	const gen = edition.generation;
	const panelColor = gen === "pro" ? PALETTE.panelPro : gen === "slim" ? PALETTE.panelSlim : PALETTE.panel;
	const coreColor = gen === "pro" ? PALETTE.corePro : PALETTE.core;
	const panelH = edition.height * .955;
	const panelD = edition.depth * .97;
	const coreW = edition.wing.inner * 2 - .04;
	const coreH = edition.height * .9;
	const coreD = edition.depth * .78;
	const standH = gen === "original" ? .11 : .08;
	const standY = -edition.height / 2 - standH * .35;
	const leftParams = {
		...edition.wing,
		height: panelH,
		depth: panelD,
		side: -1
	};
	const rightParams = {
		...edition.wing,
		height: panelH,
		depth: panelD,
		side: 1
	};
	const leftRef = useLayerGroup([
		0,
		0,
		0
	], [
		-1.15,
		.05,
		0
	], showPanels, explode);
	const rightRef = useLayerGroup([
		0,
		0,
		0
	], [
		1.15,
		.05,
		0
	], showPanels, explode);
	const shellRef = useLayerGroup([
		0,
		0,
		0
	], [
		0,
		.15,
		-.35
	], showShell, explode);
	const ventTex = (0, import_react.useMemo)(() => createVentTexture(), []);
	(0, import_react.useEffect)(() => () => ventTex.dispose(), [ventTex]);
	const slimLike = gen !== "original";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: leftRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePanel, {
				params: leftParams,
				color: panelColor,
				xray
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: rightRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePanel, {
				params: rightParams,
				color: panelColor,
				xray
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: shellRef,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundedBox, {
					args: [
						coreW,
						coreH,
						coreD
					],
					radius: .07,
					smoothness: 4,
					castShadow: true,
					receiveShadow: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
						color: coreColor,
						roughness: .48,
						metalness: .18,
						transparent: xray,
						opacity: xrayOp$1(xray, 1, .18),
						depthWrite: !xray
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						-coreW / 2 - .002,
						.05,
						0
					],
					rotation: [
						0,
						Math.PI / 2,
						0
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [coreD * .72, coreH * .78] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						map: ventTex,
						color: PALETTE.vent,
						roughness: .7,
						transparent: xray,
						opacity: xrayOp$1(xray, 1, .25),
						depthWrite: !xray,
						side: 2
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						coreW / 2 + .002,
						.05,
						0
					],
					rotation: [
						0,
						-Math.PI / 2,
						0
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [coreD * .72, coreH * .78] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						map: ventTex,
						color: PALETTE.vent,
						roughness: .7,
						transparent: xray,
						opacity: xrayOp$1(xray, 1, .25),
						depthWrite: !xray,
						side: 2
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ports, {
					coreW,
					coreH,
					coreD,
					hasDisc: edition.hasDisc && gen === "original",
					slimLike
				}),
				gen === "pro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
					position: [
						0,
						coreH * .36,
						coreD / 2 + .014
					],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
						.22,
						.045,
						.01
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: PALETTE.badge,
						emissive: PALETTE.badge,
						emissiveIntensity: .7,
						metalness: .4,
						roughness: .3
					})] })
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			position: [
				0,
				standY,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				receiveShadow: true,
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					gen === "original" ? .62 : .48,
					gen === "original" ? .7 : .54,
					standH,
					32
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: PALETTE.stand,
					roughness: .55,
					metalness: .2,
					transparent: xray,
					opacity: xrayOp$1(xray, 1, .35),
					depthWrite: !xray
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					standH * .55,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.16,
					.16,
					.04,
					20
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.rubber,
					roughness: .85
				})]
			})]
		})
	] });
}
function xrayOp(xray, solid, ghost) {
	return xray ? ghost : solid;
}
function Fan({ edition, show, explode, xray }) {
	const gen = edition.generation;
	const r = gen === "pro" ? .56 : gen === "slim" ? .46 : .52;
	const ref = useLayerGroup([
		0,
		edition.height * .28,
		.02
	], [
		0,
		1.45,
		.15
	], show, explode);
	const blades = (0, import_react.useRef)(null);
	const count = gen === "pro" ? 9 : 7;
	useFrame((_, raw) => {
		if (!blades.current || !show) return;
		blades.current.rotation.y += 7.5 * Math.min(raw, .1);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					0,
					0,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					r + .04,
					r + .04,
					.09,
					32
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.core,
					roughness: .5,
					metalness: .25,
					transparent: xray,
					opacity: xrayOp(xray, 1, .35),
					depthWrite: !xray
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				r * .22,
				r * .22,
				.1,
				20
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.fanHub,
				metalness: .4,
				roughness: .4
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: blades,
				children: Array.from({ length: count }, (_, i) => {
					const a = i / count * Math.PI * 2;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
						position: [
							Math.sin(a) * r * .42,
							0,
							Math.cos(a) * r * .42
						],
						rotation: [
							.45,
							a,
							.15
						],
						castShadow: true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
							.14,
							.018,
							r * .72
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
							color: PALETTE.fanBlade,
							roughness: .35,
							metalness: .15,
							side: 2
						})]
					}, i);
				})
			})
		]
	});
}
function Heatsink({ edition, show, explode, xray }) {
	const gen = edition.generation;
	const count = gen === "pro" ? 40 : gen === "slim" ? 22 : 30;
	const finH = gen === "pro" ? 1.15 : gen === "slim" ? .82 : .98;
	const finW = gen === "pro" ? 1.05 : gen === "slim" ? .82 : .92;
	const span = gen === "pro" ? 1.05 : gen === "slim" ? .78 : .92;
	const finT = .014;
	const ref = useLayerGroup([
		0,
		edition.height * .02,
		-.08
	], [
		.7,
		.15,
		-.1
	], show, explode);
	const meshRef = (0, import_react.useRef)(null);
	(0, import_react.useLayoutEffect)(() => {
		const mesh = meshRef.current;
		if (!mesh) return;
		const dummy = new Object3D();
		for (let i = 0; i < count; i++) {
			const t = i / (count - 1);
			dummy.position.set(0, 0, MathUtils.lerp(-span / 2, span / 2, t));
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		mesh.instanceMatrix.needsUpdate = true;
		mesh.computeBoundingSphere();
	}, [count, span]);
	const pipes = gen === "pro" ? 5 : 3;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					-finH / 2 - .04,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					finW * .72,
					.045,
					span * .85
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.copper,
					metalness: .92,
					roughness: .22,
					transparent: xray,
					opacity: xrayOp(xray, 1, .55),
					depthWrite: !xray
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
				ref: meshRef,
				args: [
					void 0,
					void 0,
					count
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					finW,
					finH,
					finT
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.aluminum,
					metalness: .86,
					roughness: .22,
					transparent: xray,
					opacity: xrayOp(xray, 1, .45),
					depthWrite: !xray
				})]
			}),
			Array.from({ length: pipes }, (_, i) => {
				const z = (i - (pipes - 1) / 2) * .12;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						-finW * .28,
						-finH * .15,
						z
					],
					rotation: [
						0,
						0,
						Math.PI / 2
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.018,
						.018,
						finW * .7,
						10
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: PALETTE.copperPipe,
						metalness: .9,
						roughness: .18
					})]
				}, i);
			})
		]
	});
}
function Motherboard({ edition, show, explode, xray }) {
	const gen = edition.generation;
	const w = gen === "slim" ? 1.15 : 1.35;
	const d = gen === "slim" ? 1.35 : 1.55;
	const ref = useLayerGroup([
		-.02,
		-edition.height * .02,
		.02
	], [
		-.85,
		-.05,
		.15
	], show, explode);
	const chips = (0, import_react.useMemo)(() => {
		const extras = gen === "pro" ? 2 : 0;
		const base = [
			[-.28, .22],
			[.28, .22],
			[-.28, -.22],
			[.28, -.22],
			[-.42, 0],
			[.42, 0],
			[0, .38],
			[0, -.38]
		];
		if (extras) base.push([-.42, .38], [.42, -.38]);
		return base;
	}, [gen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				receiveShadow: true,
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					w,
					.035,
					d
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.pcb,
					roughness: .62,
					metalness: .08,
					transparent: xray,
					opacity: xrayOp(xray, 1, .5),
					depthWrite: !xray
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.05,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.34,
					.055,
					.34
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.ihs,
					metalness: .75,
					roughness: .28
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.085,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.2,
					.012,
					.2
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.silicon,
					roughness: .4
				})]
			}),
			chips.map(([x, z], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					.04,
					z
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.12,
					.03,
					.14
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.gddr,
					metalness: .35,
					roughness: .4
				})]
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.04,
					d * .38
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					w * .55,
					.028,
					.16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.core,
					metalness: .4,
					roughness: .35
				})]
			}),
			[
				-.48,
				-.38,
				.38,
				.48
			].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					.06,
					-d * .32
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.025,
					.025,
					.07,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1c2430",
					roughness: .45,
					metalness: .2
				})]
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.12,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					w * .92,
					.012,
					d * .88
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.shield,
					metalness: .82,
					roughness: .28,
					transparent: true,
					opacity: xray ? .22 : .55,
					depthWrite: false
				})]
			})
		]
	});
}
function PowerSupply({ edition, show, explode, xray }) {
	const gen = edition.generation;
	const w = gen === "slim" ? .72 : .82;
	const h = gen === "pro" ? .72 : .58;
	const d = edition.depth * .55;
	const ref = useLayerGroup([
		0,
		-edition.height * .32,
		0
	], [
		0,
		-1.35,
		.1
	], show, explode);
	const honey = (0, import_react.useMemo)(() => createHoneyTexture(), []);
	(0, import_react.useEffect)(() => () => honey.dispose(), [honey]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					w,
					h,
					d
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.psu,
					metalness: .45,
					roughness: .4,
					transparent: xray,
					opacity: xrayOp(xray, 1, .4),
					depthWrite: !xray
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					0,
					d / 2 + .002
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [w * .85, h * .7] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: honey,
					color: PALETTE.psuMetal,
					metalness: .5,
					roughness: .45,
					transparent: xray,
					opacity: xrayOp(xray, 1, .4)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					h / 2 + .02,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.18,
					.03,
					.12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.aluminumDark,
					metalness: .6,
					roughness: .3
				})]
			})
		]
	});
}
function DiscDrive({ edition, show, explode, xray }) {
	const slim = edition.generation !== "original";
	const ref = useLayerGroup(slim ? [
		edition.width * .42,
		.05,
		0
	] : [
		.12,
		.06,
		edition.depth * .22
	], slim ? [
		1.25,
		.1,
		.2
	] : [
		.15,
		.1,
		1.05
	], show && edition.hasDisc, explode);
	const w = slim ? .22 : .55;
	const h = slim ? 1.55 : .22;
	const d = slim ? 1.7 : 1.15;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					w,
					h,
					d
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.drive,
					roughness: .48,
					metalness: .2,
					transparent: xray,
					opacity: xrayOp(xray, 1, .4),
					depthWrite: !xray
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: slim ? [
					w / 2 + .002,
					.15,
					d / 2 - .08
				] : [
					0,
					0,
					d / 2 + .002
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: slim ? [
					.02,
					.06,
					.55
				] : [
					.42,
					.05,
					.02
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#050508",
					roughness: .7
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: slim ? [
					0,
					-h * .28,
					0
				] : [
					0,
					.08,
					-.1
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: slim ? [
					w * .6,
					.12,
					d * .4
				] : [
					.28,
					.05,
					.35
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: PALETTE.driveFace,
					metalness: .35,
					roughness: .4
				})]
			})
		]
	});
}
function Internals({ edition, layers, explode, xray }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fan, {
			edition,
			show: layers.fan,
			explode,
			xray
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heatsink, {
			edition,
			show: layers.heatsink,
			explode,
			xray
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Motherboard, {
			edition,
			show: layers.motherboard,
			explode,
			xray
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerSupply, {
			edition,
			show: layers.psu,
			explode,
			xray
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscDrive, {
			edition,
			show: layers.discDrive,
			explode,
			xray
		})
	] });
}
function PS5Model() {
	const editionId = useVizStore((s) => s.edition);
	const layers = useVizStore((s) => s.layers);
	const viewMode = useVizStore((s) => s.viewMode);
	const edition = EDITIONS[editionId];
	const explode = viewMode === "exploded";
	const xray = viewMode === "xray";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleBody, {
		edition,
		showPanels: layers.sidePanels,
		showShell: layers.shell,
		explode,
		xray
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Internals, {
		edition,
		layers,
		explode,
		xray
	})] }, edition.id);
}
var CAM = {
	exterior: new Vector3(4.15, 1.35, 5.7),
	interior: new Vector3(3.35, .9, 3.55),
	heatsink: new Vector3(2.15, .45, 2.25),
	exploded: new Vector3(5.4, 2.05, 6.2),
	presentation: new Vector3(4.4, 1.5, 5.9),
	xray: new Vector3(3.9, 1.55, 5.15)
};
var LOOK = {
	exterior: new Vector3(0, .05, 0),
	interior: new Vector3(0, .05, 0),
	heatsink: new Vector3(0, .05, -.05),
	exploded: new Vector3(0, .1, 0),
	presentation: new Vector3(0, .08, 0),
	xray: new Vector3(0, .05, 0)
};
function CameraRig({ controlsRef }) {
	const { camera } = useThree();
	const viewMode = useVizStore((s) => s.viewMode);
	const resetNonce = useVizStore((s) => s.resetNonce);
	const edition = useVizStore((s) => s.edition);
	const active = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		active.current = true;
		if (resetNonce > 0) controlsRef.current?.reset();
	}, [
		viewMode,
		resetNonce,
		edition,
		controlsRef
	]);
	useFrame((_, raw) => {
		const dt = Math.min(raw, .1);
		const controls = controlsRef.current;
		if (!controls || !active.current) return;
		const k = 1 - Math.exp(-3.2 * dt);
		camera.position.lerp(CAM[viewMode], k);
		controls.target.lerp(LOOK[viewMode], k);
		if (camera.position.distanceTo(CAM[viewMode]) < .03) active.current = false;
	}, 1);
	return null;
}
function CaptureAndHint() {
	const { gl } = useThree();
	const captureNonce = useVizStore((s) => s.captureNonce);
	const setFlash = useVizStore((s) => s.setFlash);
	const dismissHint = useVizStore((s) => s.dismissHint);
	const prev = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const onPointer = () => dismissHint();
		gl.domElement.addEventListener("pointerdown", onPointer);
		return () => gl.domElement.removeEventListener("pointerdown", onPointer);
	}, [gl, dismissHint]);
	(0, import_react.useEffect)(() => {
		if (captureNonce === 0 || captureNonce === prev.current) return;
		prev.current = captureNonce;
		const edition = useVizStore.getState().edition;
		const url = gl.domElement.toDataURL("image/png");
		const a = document.createElement("a");
		a.href = url;
		a.download = `ps5-visualiseur-${edition}-${Date.now()}.png`;
		a.click();
		setFlash(true);
		const t = window.setTimeout(() => setFlash(false), 180);
		return () => window.clearTimeout(t);
	}, [
		captureNonce,
		gl,
		setFlash
	]);
	return null;
}
function Stage() {
	const editionId = useVizStore((s) => s.edition);
	const edition = EDITIONS[editionId];
	const standH = edition.generation === "original" ? .11 : .08;
	const y = -edition.height / 2 - standH * .85;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				y,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [6.5, 64] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: PALETTE.bg,
				roughness: .92,
				metalness: .08
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				y + .004,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
				1.55,
				1.64,
				64
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: PALETTE.stage,
				transparent: true,
				opacity: .28
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
			position: [
				0,
				y + .01,
				0
			],
			opacity: .5,
			scale: 9,
			blur: 2.4,
			far: 4,
			color: "#000000"
		})
	] });
}
function Lights() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .22 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			PALETTE.hemiSky,
			PALETTE.hemiGround,
			.55
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("spotLight", {
			position: [
				5.2,
				8.2,
				6.2
			],
			angle: .36,
			penumbra: .72,
			intensity: 110,
			distance: 32,
			castShadow: true,
			"shadow-mapSize-width": 1024,
			"shadow-mapSize-height": 1024,
			"shadow-bias": -2e-4
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("spotLight", {
			position: [
				-6.2,
				3.4,
				-4.2
			],
			angle: .5,
			penumbra: .9,
			intensity: 38,
			color: PALETTE.led,
			distance: 24
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-2.8,
				5.4,
				4.2
			],
			intensity: .55
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				0,
				-.4,
				2.4
			],
			intensity: 7,
			color: PALETTE.led,
			distance: 7
		})
	] });
}
function Scene() {
	const controlsRef = (0, import_react.useRef)(null);
	const autoRotate = useVizStore((s) => s.viewMode) === "presentation";
	const glConfig = (0, import_react.useMemo)(() => ({
		antialias: true,
		preserveDrawingBuffer: true,
		toneMapping: 4,
		toneMappingExposure: 1.08,
		powerPreference: "high-performance"
	}), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		className: "touch-none",
		shadows: true,
		dpr: [1, 1.75],
		gl: glConfig,
		camera: {
			position: [
				4.15,
				1.35,
				5.7
			],
			fov: 34,
			near: .1,
			far: 60
		},
		style: {
			position: "absolute",
			inset: 0,
			touchAction: "none"
		},
		onCreated: ({ scene, gl }) => {
			scene.background = new Color(PALETTE.bg);
			gl.setClearColor(PALETTE.bg, 1);
			gl.shadowMap.type = 2;
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
				attach: "fog",
				args: [
					PALETTE.bg,
					11,
					26
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lights, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PS5Model, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
				ref: controlsRef,
				makeDefault: true,
				enableDamping: true,
				dampingFactor: .08,
				minDistance: 1.8,
				maxDistance: 14,
				minPolarAngle: .18,
				maxPolarAngle: Math.PI / 2 - .08,
				autoRotate,
				autoRotateSpeed: .9,
				target: [
					0,
					.05,
					0
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, { controlsRef }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaptureAndHint, {})
		]
	});
}
//#endregion
export { Scene as default };
